"""Best-effort discovery of mounted removable volumes across desktop OSes.

Never interpret a local directory as a USB automatically. Manual folder selection
is provided by the GUI when OS drive classification is incomplete.
"""
from __future__ import annotations

import ctypes
import json
import os
from pathlib import Path
import plistlib
import subprocess
import sys


def desktop_folder() -> Path:
    """Get user's actual Desktop (including Linux localized XDG desktop)."""
    home = Path.home()
    if sys.platform.startswith("linux"):
        try:
            result = subprocess.run(["xdg-user-dir", "DESKTOP"], capture_output=True,
                                    text=True, timeout=3, check=False)
            target = result.stdout.strip()
            if target:
                return Path(target).expanduser()
        except (OSError, subprocess.TimeoutExpired):
            pass
    if sys.platform == "win32":
        # Common default; also handle users who redirect Desktop to OneDrive.
        try:
            from ctypes import wintypes
            import uuid
            shell = ctypes.windll.shell32
            ole32 = ctypes.windll.ole32
            class GUID(ctypes.Structure):
                _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD),
                            ("Data3", wintypes.WORD), ("Data4", ctypes.c_byte * 8)]
            data = uuid.UUID("B4BFCC3A-DB2C-424C-B029-7FE99A87C641").bytes_le
            guid = GUID.from_buffer_copy(data)
            ptr = ctypes.c_wchar_p()
            shell.SHGetKnownFolderPath.argtypes = [ctypes.POINTER(GUID), wintypes.DWORD,
                                                    ctypes.c_void_p, ctypes.POINTER(ctypes.c_wchar_p)]
            shell.SHGetKnownFolderPath.restype = ctypes.c_long
            if shell.SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(ptr)) == 0:
                try:
                    return Path(ptr.value)
                finally:
                    ole32.CoTaskMemFree.argtypes = [ctypes.c_void_p]
                    ole32.CoTaskMemFree(ctypes.cast(ptr, ctypes.c_void_p))
        except (OSError, ValueError, AttributeError):
            pass
    return home / "Desktop"


def _linux_usb_mounts() -> list[Path]:
    try:
        raw = subprocess.check_output(["lsblk", "-J", "-o", "NAME,TYPE,TRAN,RM,MOUNTPOINTS"],
                                      timeout=4)
        devices = json.loads(raw.decode("utf-8"))["blockdevices"]
    except (OSError, ValueError, KeyError, subprocess.TimeoutExpired):
        return []
    found = []
    def walk(entries, is_usb=False):
        for item in entries:
            usb = is_usb or item.get("tran") == "usb" or str(item.get("rm", "0")) in ("1", "True", "true")
            if usb:
                for mount in item.get("mountpoints") or []:
                    if mount and Path(mount).is_dir():
                        found.append(Path(mount))
            walk(item.get("children") or [], usb)
    walk(devices)
    return found



def _linux_unmounted_usb_partitions() -> list[tuple[str, str]]:
    """Identify USB-backed *unmounted* filesystems. Do not touch internal disks."""
    try:
        raw = subprocess.check_output(
            ["lsblk", "-J", "-o", "NAME,TYPE,TRAN,RM,LABEL,FSTYPE,MOUNTPOINTS"], timeout=5
        )
        devices = json.loads(raw.decode("utf-8"))["blockdevices"]
    except (OSError, ValueError, KeyError, subprocess.TimeoutExpired):
        return []
    candidates = []

    def walk(entries, parent_usb=False):
        for item in entries:
            usb = parent_usb or str(item.get("tran", "")).lower() == "usb" or item.get("rm") in (True, 1, "1")
            children = item.get("children") or []
            # Prefer filesystem-bearing leaf partitions; USB drives with no
            # partition table are also allowed if they contain a filesystem.
            if (usb and item.get("fstype") and not any(item.get("mountpoints") or [])
                    and (item.get("type") == "part" or (item.get("type") == "disk" and not children))):
                name = item.get("name", "")
                if isinstance(name, str) and name and "/" not in name and name not in (".", ".."):
                    candidates.append(("/dev/" + name, str(item.get("label") or "")))
            walk(children, usb)

    walk(devices)
    return candidates


def refresh_usb_mount() -> tuple[Path | None, str]:
    """Rediscover USB. On Linux, explicitly try to mount ONE eligible USB.

    Called only when the user presses Refresh, not on application startup.
    No sudo, no device formatting, no implicit selection among several drives.
    """
    roots = mounted_usb_drives()
    already_preferred = [p for p in roots if p.name.upper() == "OTPKEY"]
    if already_preferred:
        return _usb_status(already_preferred[0])

    if not sys.platform.startswith("linux"):
        selected = choose_default_usb()
        return _usb_status(selected) if selected else (
            None, "USBが見つかりません。接続を確認するか「USBを選ぶ」を押してください。")

    candidates = _linux_unmounted_usb_partitions()
    preferred = [x for x in candidates if x[1].upper() == "OTPKEY"]
    if len(preferred) == 1:
        device, _ = preferred[0]
    elif len(roots) == 1:
        # Respect the currently mounted USB if it is the only mounted one,
        # and the dedicated OTPKEY was not uniquely found.
        return _usb_status(roots[0])
    elif len(roots) > 1 or len(candidates) > 1:
        return None, "USBが複数あります。「USBを選ぶ」で使用するUSBを指定してください。"
    elif len(candidates) == 1:
        device, _ = candidates[0]
    else:
        return None, "接続済み・マウント済みのUSBが見つかりません。挿し直して再検出してください。"

    try:
        result = subprocess.run(["udisksctl", "mount", "-b", device],
                                capture_output=True, text=True, timeout=18, check=False)
    except FileNotFoundError:
        return None, "USBを自動接続する機能が見つかりません。ファイルマネージャーでUSBを開いて再検出してください。"
    except (OSError, subprocess.TimeoutExpired):
        return None, "USBの接続処理が完了しませんでした。ファイルマネージャーでUSBを開いて確認してください。"
    if result.returncode != 0:
        err = (result.stderr or result.stdout).strip().replace("\n", " ")
        return None, "USBをマウントできませんでした: " + (err[:160] or "接続状態を確認してください。")
    selected = choose_default_usb()
    if selected is None:
        return None, "USBのマウントは成功しましたが、自動選択できません。「USBを選ぶ」から指定してください。"
    return _usb_status(selected)


def _usb_status(path: Path) -> tuple[Path, str]:
    if os.name != "nt" and hasattr(os, "ST_RDONLY"):
        try:
            if os.statvfs(path).f_flag & os.ST_RDONLY:
                return path, "USBを検出しましたが読み取り専用です。"
        except OSError:
            pass
    return path, "USBを検出しました。"


def _mac_usb_mounts() -> list[Path]:
    try:
        data = subprocess.check_output(["diskutil", "list", "-plist", "external"], timeout=5)
        items = plistlib.loads(data).get("AllDisksAndPartitions", [])
    except (OSError, ValueError, subprocess.TimeoutExpired):
        return []
    found = []
    def walk(items):
        for item in items:
            path = item.get("MountPoint")
            if path and Path(path).is_dir():
                found.append(Path(path))
            walk(item.get("Partitions") or [])
    walk(items)
    return found


def _windows_usb_mounts() -> list[Path]:
    # DRIVE_REMOVABLE; Windows sometimes classifies USB HDD/SSD as DRIVE_FIXED.
    # For those devices, the user can pick its folder manually.
    try:
        get_drive_type = ctypes.windll.kernel32.GetDriveTypeW
        get_drive_type.argtypes = [ctypes.c_wchar_p]
        get_drive_type.restype = ctypes.c_uint
    except AttributeError:
        return []
    return [Path(f"{letter}:\\") for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            if get_drive_type(f"{letter}:\\") == 2]


def mounted_usb_drives() -> list[Path]:
    if sys.platform.startswith("linux"):
        volumes = _linux_usb_mounts()
    elif sys.platform == "darwin":
        volumes = _mac_usb_mounts()
    elif sys.platform == "win32":
        volumes = _windows_usb_mounts()
    else:
        volumes = []
    unique = {str(p): p for p in volumes if p.is_dir()}
    # User's OTPKEY USB is preferred if other removable devices are connected.
    return sorted(unique.values(), key=lambda p: (p.name.upper() != "OTPKEY", str(p).lower()))


def choose_default_usb() -> Path | None:
    roots = mounted_usb_drives()
    if not roots:
        return None
    preferred = [p for p in roots if p.name.upper() == "OTPKEY"]
    return preferred[0] if preferred else roots[0] if len(roots) == 1 else None


def assert_writable_dir(folder: Path):
    if not folder.is_dir():
        raise OSError("USBの保存先フォルダがありません。")
    if os.name != "nt" and hasattr(os, "ST_RDONLY"):
        if os.statvfs(folder).f_flag & os.ST_RDONLY:
            raise OSError("USBが読み取り専用です。USBの状態を確認してください。")
