import os
from pathlib import Path
import tempfile
import threading
import unittest

from crypto_core import (Cancelled, VaultError, encrypt_file, decrypt_file,
                         decrypt_auto, find_matching_keys, HEADER, AUTH_SIZE)


class TestVault(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        base = Path(self.tmp.name)
        self.source = base / "src"
        self.ciphers = base / "ciphers"
        self.keys = base / "keys"
        self.restored = base / "restored"
        for p in (self.source, self.ciphers, self.keys, self.restored):
            p.mkdir()

    def roundtrip(self, name, data):
        p = self.source / name
        p.write_bytes(data)
        c, k = encrypt_file(p, self.ciphers, self.keys)
        self.assertEqual(c.parent, self.ciphers)
        self.assertEqual(k.parent, self.keys)
        self.assertNotIn(name.encode("utf-8"), c.read_bytes())
        self.assertEqual(c.stat().st_size, HEADER.size + len(data) + 2 + len(name.encode("utf-8")) + 32)
        target = decrypt_file(c, k, self.restored)
        self.assertEqual(target.name, name)
        self.assertEqual(target.read_bytes(), data)
        self.assertRaises(VaultError, decrypt_file, c, k, self.restored)
        return c, k

    def test_small_unicode(self):
        self.roundtrip("研究ノート🌱.txt", "ランダムな日本語\nこんにちは".encode())

    def test_empty(self):
        self.roundtrip("empty.dat", b"")

    def test_streaming_over_1mb(self):
        self.roundtrip("large.bin", os.urandom(2 * 1024 * 1024 + 130))

    def test_wrong_key_rejected(self):
        a = self.source / "a.txt"
        b = self.source / "b.txt"
        a.write_bytes(b"aaa")
        b.write_bytes(b"bbb")
        ca, ka = encrypt_file(a, self.ciphers, self.keys)
        cb, kb = encrypt_file(b, self.ciphers, self.keys)
        with self.assertRaises(VaultError):
            decrypt_file(ca, kb, self.restored)
        self.assertFalse(list(self.restored.iterdir()))

    def test_cipher_tamper_rejected(self):
        inp = self.source / "a.bin"
        inp.write_bytes(b"AAAAA")
        c, k = encrypt_file(inp, self.ciphers, self.keys)
        with c.open("r+b") as f:
            f.seek(HEADER.size + 3)
            a = f.read(1)
            f.seek(HEADER.size + 3)
            f.write(bytes([a[0] ^ 0x3F]))
        with self.assertRaisesRegex(VaultError, "改ざん"):
            decrypt_file(c, k, self.restored)
        self.assertFalse(list(self.restored.iterdir()))

    def test_pad_tamper_rejected(self):
        inp = self.source / "a.bin"
        inp.write_bytes(b"AAAAA")
        c, k = encrypt_file(inp, self.ciphers, self.keys)
        with k.open("r+b") as f:
            f.seek(HEADER.size + AUTH_SIZE + 3)
            a = f.read(1)
            f.seek(HEADER.size + AUTH_SIZE + 3)
            f.write(bytes([a[0] ^ 1]))
        with self.assertRaisesRegex(VaultError, "改ざん"):
            decrypt_file(c, k, self.restored)
        self.assertFalse(list(self.restored.iterdir()))

    def test_same_folder_rejected(self):
        inp = self.source / "a.txt"
        inp.write_bytes(b"ok")
        with self.assertRaises(VaultError):
            encrypt_file(inp, self.ciphers, self.ciphers)

    def test_cancelled_without_remnants(self):
        inp = self.source / "a.txt"
        inp.write_bytes(b"ok")
        flag = threading.Event()
        flag.set()
        with self.assertRaises(Cancelled):
            encrypt_file(inp, self.ciphers, self.keys, cancel=flag)
        self.assertFalse(list(self.ciphers.iterdir()))
        self.assertFalse(list(self.keys.iterdir()))

    def test_original_cipher_name_random_key_name(self):
        src = self.source / "写真2026.jpg"
        src.write_bytes(os.urandom(128))
        cipher, key = encrypt_file(src, self.ciphers, self.keys)
        self.assertEqual(cipher.name, "写真2026.jpg.otv")
        self.assertRegex(key.name, r"^[0-9a-f]{40}\.otk$")
        self.assertNotIn("写真", key.name)
        self.assertEqual(decrypt_file(cipher, key, self.restored).read_bytes(), src.read_bytes())

    def test_both_file_names_may_change_entirely(self):
        src = self.source / "研究報告.txt"
        src.write_text("内容はそのままです。", encoding="utf-8")
        cipher, key = encrypt_file(src, self.ciphers, self.keys)
        # No .otv or .otk extension is needed to identify matching files.
        new_cipher = cipher.rename(self.ciphers / "renamed.file")
        subdir = self.keys / "nested" / "more"
        subdir.mkdir(parents=True)
        new_key = key.rename(subdir / "whatever.data")
        path, identified_key = decrypt_auto(new_cipher, [self.keys], self.restored)
        self.assertEqual(identified_key, new_key)
        self.assertEqual(path.name, src.name)
        self.assertEqual(path.read_bytes(), src.read_bytes())

    def test_multiple_keys_autoselection(self):
        a = self.source / "a.bin"
        b = self.source / "b.bin"
        a.write_bytes(b"AAA")
        b.write_bytes(b"BBB")
        ca, ka = encrypt_file(a, self.ciphers, self.keys)
        cb, kb = encrypt_file(b, self.ciphers, self.keys)
        out, found_key = decrypt_auto(cb, [self.keys], self.restored)
        self.assertEqual(found_key, kb)
        self.assertEqual(out.read_bytes(), b"BBB")
        self.assertEqual(find_matching_keys(ca, [self.keys]), [ka])

    def test_repeat_encryption_does_not_overwrite(self):
        src = self.source / "photo.jpg"
        src.write_bytes(b"original")
        a, keya = encrypt_file(src, self.ciphers, self.keys)
        b, keyb = encrypt_file(src, self.ciphers, self.keys)
        self.assertEqual(a.name, "photo.jpg.otv")
        self.assertEqual(b.name, "photo.jpg (2).otv")
        self.assertNotEqual(keya.name, keyb.name)
        self.assertTrue(a.exists() and b.exists())

    def test_matching_id_but_corrupted_key_can_fall_back(self):
        src = self.source / "z.bin"
        src.write_bytes(b"hello")
        cipher, key = encrypt_file(src, self.ciphers, self.keys)
        broken = self.keys / "0-fake"
        broken.write_bytes(key.read_bytes())
        with broken.open("r+b") as fh:
            fh.seek(-1, 2)
            byte = fh.read(1)
            fh.seek(-1, 2)
            fh.write(bytes([byte[0] ^ 1]))
        restored, selected = decrypt_auto(cipher, [self.keys], self.restored)
        self.assertEqual(selected, key)
        self.assertEqual(restored.read_bytes(), b"hello")

    def test_missing_usb_key_clear_error(self):
        src = self.source / "missing.txt"
        src.write_bytes(b"secret")
        cipher, key = encrypt_file(src, self.ciphers, self.keys)
        key.unlink()
        with self.assertRaisesRegex(VaultError, "USB内に対応する鍵がありません"):
            decrypt_auto(cipher, [self.keys], self.restored)

    def test_hardware_xor_mix(self):
        # Exercise the optional hardware mixing path with a simulated device.
        fake = Path(self.tmp.name) / "fake-device"
        fake.write_bytes(os.urandom(1024))
        inp = self.source / "a.bin"
        inp.write_bytes(os.urandom(500))
        c, k = encrypt_file(inp, self.ciphers, self.keys, mode="hardware-mix", hardware_path=str(fake))
        restored = decrypt_file(c, k, self.restored)
        self.assertEqual(inp.read_bytes(), restored.read_bytes())


if __name__ == "__main__":
    unittest.main()
