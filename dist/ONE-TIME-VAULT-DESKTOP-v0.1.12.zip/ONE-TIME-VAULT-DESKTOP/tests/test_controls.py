from pathlib import Path
import os
import tempfile
import unittest
from crypto_core import encrypt_file, decrypt_auto
from folder_core import encrypt_folder


@unittest.skipIf(os.name == 'nt', 'Windows does not allow control characters in filenames')
class TestControlNames(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        base = Path(tmp.name)
        self.src = base / 'original'
        self.cipher = base / 'cipher'
        self.keys = base / 'key'
        self.out = base / 'out'
        for p in (self.src, self.cipher, self.keys, self.out):
            p.mkdir()

    def test_file_control_char(self):
        original = self.src / '写真\n一枚目\t.txt'
        original.write_bytes(b'Hello encrypted image!')
        encrypted, key = encrypt_file(original, self.cipher, self.keys)
        self.assertNotIn('\n', encrypted.name)
        self.assertNotIn('\t', encrypted.name)
        self.assertEqual(encrypted.name, '写真~U000A~一枚目~U0009~.txt.otv')
        encrypted.rename(self.cipher / 'anything')
        key.rename(self.keys / 'changed-random-name')
        restored, found = decrypt_auto(self.cipher / 'anything', [self.keys], self.out)
        self.assertEqual(restored.name, original.name)
        self.assertEqual(restored.read_bytes(), original.read_bytes())

    def test_folder_control_char_nested(self):
        original = self.src / '音楽\n2026'
        subdir = original / '仕事\tメモ'
        subdir.mkdir(parents=True)
        (subdir / 'abc\rdef.txt').write_text('secret!', encoding='utf-8')
        (original / '空\nフォルダ').mkdir()
        encrypted, key = encrypt_folder(original, self.cipher, self.keys)
        self.assertNotIn('\n', encrypted.name)
        self.assertIn('~U000A~', encrypted.name)
        encrypted = encrypted.rename(self.cipher / 'changed-name.xyz')
        key = key.rename(self.keys / 'secret-key')
        result, used_key = decrypt_auto(encrypted, [self.keys], self.out)
        self.assertEqual(used_key, key)
        self.assertEqual(result.name, original.name)
        self.assertEqual((result / '仕事\tメモ' / 'abc\rdef.txt').read_text(encoding='utf-8'), 'secret!')
        self.assertTrue((result / '空\nフォルダ').is_dir())

if __name__ == '__main__':
    unittest.main()
