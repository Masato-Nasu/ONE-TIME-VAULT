"""Regression checks for fast XOR and periodic USB-key commit."""
import os
import random
import tempfile
from pathlib import Path
from unittest import TestCase
from unittest.mock import patch

import crypto_core as c
import folder_core as f


class SpeedupChecks(TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name)
        for name in ('data', 'encrypted', 'usb', 'restored'):
            (self.root / name).mkdir()

    def test_xor_is_exactly_old_bytewise_xor(self):
        random.seed(2026)
        for n in (0, 1, 3, 7, 31, 1024, 65536, 1048576):
            a, b = os.urandom(n), os.urandom(n)
            expect = bytes(x ^ y for x, y in zip(a, b))
            self.assertEqual(c._xor(a, b), expect)
            self.assertEqual(c._xor(c._xor(a, b), b), a)
        self.assertEqual(c._xor(b'\x00\x00', b'\x00\x00'), b'\x00\x00')
        with self.assertRaises(c.VaultError):
            c._xor(b'abc', b'ab')

    def test_file_periodic_commit_and_compatibility(self):
        src = self.root / 'data' / 'file.bin'
        src.write_bytes(os.urandom(3 * 1024 * 1024 + 1))
        reports=[]
        # Tight threshold makes it easy to test without a huge file.
        with patch.object(c, 'KEY_SYNC_INTERVAL', 1024 * 1024):
            encrypted, key = c.encrypt_file(src, self.root / 'encrypted', self.root / 'usb', progress=lambda *x:reports.append(x))
        phases=[r[0] for r in reports]
        self.assertGreaterEqual(phases.count('USBの鍵を段階保存中'), 3)
        self.assertLess(phases.index('USBの鍵を段階保存中'), phases.index('USBの鍵を保存中'))
        self.assertEqual(key.stat().st_size, encrypted.stat().st_size + 32)
        output, matched = c.decrypt_auto(encrypted, [self.root / 'usb'], self.root / 'restored')
        self.assertEqual(output.read_bytes(), src.read_bytes())
        self.assertEqual(matched, key)

    def test_folder_periodic_commit_and_compatibility(self):
        src = self.root / 'data' / 'sample'
        src.mkdir()
        (src / 'inner').mkdir()
        (src / 'inner' / 'a.bin').write_bytes(os.urandom(3 * 1024 * 1024 + 1))
        reports=[]
        with patch.object(c, 'KEY_SYNC_INTERVAL', 1024 * 1024):
            encrypted, key = f.encrypt_folder(src, self.root / 'encrypted', self.root / 'usb', progress=lambda *x:reports.append(x))
        self.assertGreaterEqual([r[0] for r in reports].count('USBの鍵を段階保存中'), 3)
        output, matched = c.decrypt_auto(encrypted, [self.root / 'usb'], self.root / 'restored')
        self.assertEqual((output / 'inner' / 'a.bin').read_bytes(), (src / 'inner' / 'a.bin').read_bytes())
        self.assertEqual(matched, key)

    def test_disk_error_during_periodic_sync_leaves_no_published_file(self):
        src = self.root / 'data' / 'a.bin'
        src.write_bytes(os.urandom(2 * 1024 * 1024))
        with patch.object(c, 'KEY_SYNC_INTERVAL', 1024 * 1024), patch('crypto_core.os.fsync', side_effect=OSError('test failure')):
            with self.assertRaises(OSError):
                c.encrypt_file(src, self.root / 'encrypted', self.root / 'usb')
        self.assertEqual(list((self.root / 'encrypted').iterdir()), [])
        self.assertEqual(list((self.root / 'usb').iterdir()), [])
