"""Regression tests for false positives and genuinely volatile inputs."""
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import folder_core
from crypto_core import VaultError, decrypt_auto


class TestLiveTree(unittest.TestCase):
    def setUp(self):
        self.t = tempfile.TemporaryDirectory()
        self.addCleanup(self.t.cleanup)
        base = Path(self.t.name)
        self.src, self.enc, self.usb, self.dst = [base / s for s in ('project', 'encrypted', 'usb', 'decrypted')]
        for p in (self.src, self.enc, self.usb, self.dst):
            p.mkdir()

    def test_directory_mtime_change_does_not_abort(self):
        work = self.src / 'nested'
        work.mkdir()
        (work / 'file.txt').write_text('stays the same')
        original = folder_core._scan

        def scan_then_touch(*args, **kwargs):
            result = original(*args, **kwargs)
            (work / '.ephemeral').write_text('newly created after scan')
            # Parent directory mtime changes, but scanned file bytes are unchanged.
            return result

        with patch.object(folder_core, '_scan', side_effect=scan_then_touch):
            cipher, key = folder_core.encrypt_folder(self.src, self.enc, self.usb)
        restored, selected = decrypt_auto(cipher, [self.usb], self.dst)
        self.assertEqual(selected, key)
        self.assertEqual((restored / 'nested' / 'file.txt').read_text(), 'stays the same')
        # A scan is a point-in-time enumeration, so later new files not included.
        self.assertFalse((restored / 'nested' / '.ephemeral').exists())

    def test_real_file_edit_is_rejected_and_temp_files_removed(self):
        p = self.src / 'notes.txt'
        p.write_text('first')
        original = folder_core._scan

        def scan_then_edit(*args, **kwargs):
            result = original(*args, **kwargs)
            p.write_text('changed data, different size')
            return result

        with patch.object(folder_core, '_scan', side_effect=scan_then_edit):
            with self.assertRaisesRegex(VaultError, 'notes.txt'):
                folder_core.encrypt_folder(self.src, self.enc, self.usb)
        self.assertEqual(list(self.enc.iterdir()), [])
        self.assertEqual(list(self.usb.iterdir()), [])

    def test_exclusion_is_opt_in_and_reported(self):
        virtual_env = self.src / '.venv'
        virtual_env.mkdir()
        (virtual_env / 'packages.txt').write_text('reinstallable')
        (self.src / 'main.py').write_text('print(1)')
        cipher1, key1 = folder_core.encrypt_folder(self.src, self.enc, self.usb)
        path1, _ = decrypt_auto(cipher1, [self.usb], self.dst)
        self.assertTrue((path1 / '.venv' / 'packages.txt').exists())
        # Can restore a second archive under a new output directory.
        dst2 = self.dst.parent / 'decrypted2'
        dst2.mkdir()
        skipped = []
        cipher2, key2 = folder_core.encrypt_folder(self.src, self.enc, self.usb,
                                                    skipped=skipped, exclude_generated=True)
        self.assertEqual(skipped, ['.venv/ (開発環境)'])
        path2, _ = decrypt_auto(cipher2, [self.usb], dst2)
        self.assertFalse((path2 / '.venv').exists())
        self.assertEqual((path2 / 'main.py').read_text(), 'print(1)')

    def test_scan_progress_reports_items(self):
        (self.src / 'f').write_bytes(b'abc')
        reports = []
        folder_core.encrypt_folder(self.src, self.enc, self.usb, progress=lambda *args: reports.append(args))
        self.assertTrue(any(a[0] == '確認' and a[2] == 0 and a[1] > 0 for a in reports))
        self.assertTrue(any(a[0] == '暗号化' and a[1] == a[2] for a in reports))


if __name__ == '__main__':
    unittest.main()
