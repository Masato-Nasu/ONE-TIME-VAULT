from pathlib import Path
import os
import tempfile
import threading
import unittest

from crypto_core import (Cancelled, VaultError, decrypt_auto, decrypt_file,
                         encrypt_file, find_matching_keys, HEADER, AUTH_SIZE)
from folder_core import encrypt_folder


class TestFolders(unittest.TestCase):
    def setUp(self):
        t = tempfile.TemporaryDirectory()
        self.addCleanup(t.cleanup)
        base = Path(t.name)
        self.src = base / "src"
        self.cipher = base / "cipher"
        self.keys = base / "usb"
        self.out = base / "out"
        for p in (self.src, self.cipher, self.keys, self.out):
            p.mkdir()

    def make_tree(self):
        p = self.src / "旅行2026"
        (p / "写真" / "一日目").mkdir(parents=True)
        (p / "空フォルダ").mkdir()
        (p / "写真" / "一日目" / "画像.jpg").write_bytes(os.urandom(2 * 1024 * 1024 + 17))
        (p / "日本語.txt").write_text("こんにちは🤖", encoding="utf-8")
        (p / ".hidden").write_bytes(b"")
        return p

    def test_nested_roundtrip(self):
        p = self.make_tree()
        cipher, key = encrypt_folder(p, self.cipher, self.keys)
        self.assertEqual(cipher.name, "旅行2026.otv")
        self.assertRegex(key.name, r"^[0-9a-f]{40}\.otk$")
        self.assertNotIn(b"\xe3\x81\x93\xe3\x82\x93", cipher.read_bytes())
        restored, selected = decrypt_auto(cipher, [self.keys], self.out)
        self.assertEqual(selected, key)
        self.assertEqual(restored.name, p.name)
        self.assertEqual((restored / "日本語.txt").read_text(), "こんにちは🤖")
        self.assertEqual((restored / ".hidden").read_bytes(), b"")
        self.assertTrue((restored / "空フォルダ").is_dir())
        self.assertEqual((restored / "写真/一日目/画像.jpg").read_bytes(),
                         (p / "写真/一日目/画像.jpg").read_bytes())
        self.assertRaisesRegex(VaultError, "同名ファイル", decrypt_file, cipher, key, self.out)
        self.assertEqual(sorted(f.name for f in self.out.iterdir()), [p.name])
        self.assertEqual(sorted(f.name for f in self.cipher.iterdir()), [cipher.name])
        self.assertEqual(sorted(f.name for f in self.keys.iterdir()), [key.name])

    def test_empty_and_renamed(self):
        p = self.src / "空っぽ"
        p.mkdir()
        cipher, key = encrypt_folder(p, self.cipher, self.keys)
        cipher = cipher.rename(self.cipher / "nothing.random")
        other = self.keys / "sub"
        other.mkdir()
        key = key.rename(other / "random.name")
        result, matched = decrypt_auto(cipher, [self.keys], self.out)
        self.assertEqual(matched, key)
        self.assertEqual(result.name, "空っぽ")
        self.assertEqual(list(result.iterdir()), [])

    def test_tamper_cipher(self):
        p = self.make_tree()
        cipher, key = encrypt_folder(p, self.cipher, self.keys)
        with cipher.open("r+b") as f:
            f.seek(HEADER.size + 20)
            v = f.read(1)
            f.seek(HEADER.size + 20)
            f.write(bytes([v[0] ^ 0x32]))
        with self.assertRaisesRegex(VaultError, "改ざん"):
            decrypt_file(cipher, key, self.out)
        self.assertEqual(list(self.out.iterdir()), [])

    def test_tamper_key(self):
        p = self.make_tree()
        cipher, key = encrypt_folder(p, self.cipher, self.keys)
        with key.open("r+b") as f:
            f.seek(HEADER.size + AUTH_SIZE + 20)
            v = f.read(1)
            f.seek(HEADER.size + AUTH_SIZE + 20)
            f.write(bytes([v[0] ^ 0x32]))
        with self.assertRaisesRegex(VaultError, "改ざん"):
            decrypt_file(cipher, key, self.out)
        self.assertEqual(list(self.out.iterdir()), [])

    def test_multiple_key_matching_both_types(self):
        p = self.make_tree()
        cipher, key = encrypt_folder(p, self.cipher, self.keys)
        f = self.src / "text.txt"
        f.write_text("test")
        c2, k2 = encrypt_file(f, self.cipher, self.keys)
        self.assertEqual(find_matching_keys(cipher, [self.keys]), [key])
        self.assertEqual(find_matching_keys(c2, [self.keys]), [k2])
        self.assertEqual(decrypt_auto(cipher, [self.keys], self.out)[1], key)
        self.assertEqual(decrypt_auto(c2, [self.keys], self.out)[1], k2)

    def test_cancel_cleanup(self):
        p = self.make_tree()
        event = threading.Event()
        event.set()
        with self.assertRaises(Cancelled):
            encrypt_folder(p, self.cipher, self.keys, cancel=event)
        self.assertEqual(list(self.keys.iterdir()), [])
        self.assertEqual(list(self.cipher.iterdir()), [])

    @unittest.skipIf(os.name == "nt", "symlink creation on Windows may require privileges")
    def test_symlink_dirs_are_skipped_and_reported(self):
        p = self.make_tree()
        # Reproduce a venv's lib64 -> lib entry; also ensure links pointing
        # outside the tree cannot pull in unrelated private data.
        (p / ".venv" / "lib").mkdir(parents=True)
        (p / ".venv" / "lib" / "inside.py").write_text("inside")
        (p / ".venv" / "lib64").symlink_to("lib", target_is_directory=True)
        external = self.src / "external-data"
        external.mkdir()
        (external / "DO-NOT-INCLUDE.txt").write_text("external secret")
        (p / "outside").symlink_to(external, target_is_directory=True)
        (p / "link-to-file").symlink_to(p / "日本語.txt")
        (p / "broken").symlink_to("missing-file")
        ignored = []
        cipher, key = encrypt_folder(p, self.cipher, self.keys, skipped=ignored)
        self.assertEqual(set(ignored), {".venv/lib64", "outside", "link-to-file", "broken"})
        restored, chosen_key = decrypt_auto(cipher, [self.keys], self.out)
        self.assertEqual(chosen_key, key)
        self.assertEqual((restored / ".venv/lib/inside.py").read_text(), "inside")
        self.assertTrue((restored / "空フォルダ").is_dir())
        self.assertFalse((restored / ".venv/lib64").exists())
        self.assertFalse((restored / "outside").exists())
        self.assertFalse((restored / "link-to-file").exists())
        self.assertFalse((restored / "broken").exists())
        self.assertFalse((restored / "DO-NOT-INCLUDE.txt").exists())

    @unittest.skipIf(os.name == "nt", "FIFO is POSIX-only")
    def test_special_file_skipped_and_reported(self):
        p = self.src / "special"
        p.mkdir()
        (p / "normal.txt").write_text("ok")
        os.mkfifo(p / "pipe")
        ignored = []
        cipher, key = encrypt_folder(p, self.cipher, self.keys, skipped=ignored)
        self.assertEqual(ignored, ["pipe"])
        restored, _ = decrypt_auto(cipher, [self.keys], self.out)
        self.assertEqual((restored / "normal.txt").read_text(), "ok")
        self.assertFalse((restored / "pipe").exists())

    def test_normal_tree_reports_nothing_skipped(self):
        p = self.make_tree()
        ignored = []
        cipher, key = encrypt_folder(p, self.cipher, self.keys, skipped=ignored)
        self.assertEqual(ignored, [])
        restored, _ = decrypt_auto(cipher, [self.keys], self.out)
        self.assertTrue((restored / "空フォルダ").is_dir())

    def test_repeat_no_overwrite(self):
        p = self.make_tree()
        a, ka = encrypt_folder(p, self.cipher, self.keys)
        b, kb = encrypt_folder(p, self.cipher, self.keys)
        self.assertEqual(a.name, "旅行2026.otv")
        self.assertEqual(b.name, "旅行2026 (2).otv")
        self.assertNotEqual(ka, kb)

    def test_hw_fake(self):
        p = self.src / "ok"
        p.mkdir()
        (p / "t").write_bytes(b"hello")
        fake = self.src / "hardware"
        fake.write_bytes(os.urandom(2048))
        c, k = encrypt_folder(p, self.cipher, self.keys, "hardware-mix", hardware_path=str(fake))
        self.assertEqual((decrypt_file(c, k, self.out) / "t").read_bytes(), b"hello")

    def test_root_conflict(self):
        p = self.src / "mine"
        p.mkdir()
        c, k = encrypt_folder(p, self.cipher, self.keys)
        (self.out / "mine").mkdir()
        with self.assertRaisesRegex(VaultError, "同名"):
            decrypt_file(c, k, self.out)

if __name__ == "__main__":
    unittest.main()
