"""Localization regression tests: preferences and legacy error presentation."""
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from i18n import UI, load_language, save_language, phase_text, t, translate_external


class LocalizationTests(unittest.TestCase):
    def test_both_locales_have_identical_labels(self):
        self.assertEqual(set(UI['ja']), set(UI['en']))
        for code, values in UI.items():
            for key, label in values.items():
                self.assertTrue(label, f'{code}.{key}')

    def test_english_buttons(self):
        self.assertEqual(t('en', 'encrypt_action'), 'Encrypt')
        self.assertEqual(t('en', 'decrypt_action'), 'Decrypt')
        self.assertEqual(t('ja', 'quit'), '終了')

    def test_language_preference_round_trip(self):
        with tempfile.TemporaryDirectory() as d:
            with patch.dict(os.environ, {'XDG_CONFIG_HOME': d}):
                self.assertEqual(load_language(), 'ja')
                save_language('en')
                self.assertEqual(load_language(), 'en')
                self.assertEqual(json.loads((Path(d) / 'one-time-vault' / 'settings.json').read_text()), {'language': 'en'})
                save_language('ja')
                self.assertEqual(load_language(), 'ja')

    def test_translate_core_errors(self):
        self.assertEqual(translate_external('en', 'USB内に対応する鍵がありません。鍵が保存されたUSBを挿してください。'),
                         'No matching key was found on the USB. Insert the USB containing the key.')
        self.assertIn('changed during', translate_external('en', '暗号化中にファイルが変更されました: folder/a.txt'))
        self.assertIn('read-only', translate_external('en', 'USBを検出しましたが読み取り専用です。'))
        self.assertEqual(translate_external('ja', '鍵ファイルが壊れています。'), '鍵ファイルが壊れています。')
        message = 'USBの空き容量が足りません。鍵には約 486.4 MB 必要ですが、空きは約 400.0 MB です。'
        translated = translate_external('en', message)
        self.assertIn('486.4 MB', translated)
        self.assertNotIn('鍵', translated)

    def test_progress_phases(self):
        self.assertEqual(phase_text('en', 'USBの鍵を段階保存中'), 'Writing key to USB')
        self.assertEqual(phase_text('ja', 'USBの鍵を段階保存中'), 'USBの鍵を段階保存中')


if __name__ == '__main__':
    unittest.main()
