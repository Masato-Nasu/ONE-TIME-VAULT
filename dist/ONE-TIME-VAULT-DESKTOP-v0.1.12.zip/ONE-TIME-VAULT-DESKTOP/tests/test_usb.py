import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import usb_drives


class TestUSBFolders(unittest.TestCase):
    def test_linux_lsblk_usb_partition_detection(self):
        with tempfile.TemporaryDirectory() as tmp:
            disk = Path(tmp) / "OTPKEY"
            disk.mkdir()
            block = {"blockdevices": [
                {"name": "sda", "type": "disk", "tran": "usb", "rm": True, "mountpoints": [None],
                 "children": [{"name": "sda1", "type": "part", "tran": None, "rm": False,
                               "mountpoints": [str(disk)]}]},
                {"name": "nvme0n1", "type": "disk", "tran": "nvme", "rm": False,
                 "mountpoints": [None], "children": [{"name": "nvme0n1p1", "mountpoints": ["/"]}]}
            ]}
            with mock.patch.object(usb_drives.subprocess, "check_output", return_value=json.dumps(block).encode()):
                self.assertEqual(usb_drives._linux_usb_mounts(), [disk])

    def test_prefer_otpkey_volume(self):
        with mock.patch.object(usb_drives, "mounted_usb_drives", return_value=[Path("/usb/A"), Path("/usb/OTPKEY")]):
            self.assertEqual(usb_drives.choose_default_usb(), Path("/usb/OTPKEY"))

    def test_two_unidentified_usb_drives_requires_manual_selection(self):
        with mock.patch.object(usb_drives, "mounted_usb_drives", return_value=[Path("/usb/A"), Path("/usb/B")]):
            self.assertIsNone(usb_drives.choose_default_usb())

    def test_linux_japanese_desktop(self):
        dummy = mock.Mock(stdout="/home/test/デスクトップ\n")
        with mock.patch.object(usb_drives.sys, "platform", "linux"), \
             mock.patch.object(usb_drives.subprocess, "run", return_value=dummy):
            self.assertEqual(usb_drives.desktop_folder(), Path("/home/test/デスクトップ"))


if __name__ == "__main__":
    unittest.main()

class TestUSBRefresh(unittest.TestCase):
    def test_unmounted_usb_detected_by_lsblk(self):
        block = {"blockdevices": [
            {"name": "sda", "type": "disk", "tran": "usb", "rm": False,
             "mountpoints": [None], "children": [{"name": "sda1", "type": "part", "fstype": "vfat", "label": "OTPKEY", "mountpoints": [None]}]},
            {"name": "nvme0n1", "type": "disk", "tran": "nvme", "rm": False,
             "children": [{"name": "nvme0n1p5", "type": "part", "fstype": "ext4", "mountpoints": ["/"]}]}
        ]}
        with mock.patch.object(usb_drives.subprocess, "check_output", return_value=json.dumps(block).encode()):
            self.assertEqual(usb_drives._linux_unmounted_usb_partitions(), [("/dev/sda1", "OTPKEY")])

    def test_refresh_mounts_one_unmounted_otpkey(self):
        def mounted():
            return [Path('/media/user/OTPKEY')] if called[0] else []
        called = [False]
        def mount(cmd, **kwargs):
            self.assertEqual(cmd, ['udisksctl', 'mount', '-b', '/dev/sda1'])
            called[0] = True
            return mock.Mock(returncode=0, stdout='Mounted', stderr='')
        with mock.patch.object(usb_drives.sys, 'platform', 'linux'), \
             mock.patch.object(usb_drives, 'mounted_usb_drives', side_effect=mounted), \
             mock.patch.object(usb_drives, '_linux_unmounted_usb_partitions', return_value=[('/dev/sda1', 'OTPKEY')]), \
             mock.patch.object(usb_drives.subprocess, 'run', side_effect=mount), \
             mock.patch.object(usb_drives, '_usb_status', side_effect=lambda p: (p, 'USBを検出しました。')):
            path, info = usb_drives.refresh_usb_mount()
            self.assertEqual(path, Path('/media/user/OTPKEY'))
            self.assertTrue(called[0])

    def test_prefer_unmounted_otpkey_over_already_mounted_other_usb(self):
        called = []
        def mounted():
            return [Path('/media/user/OTHERVOL')] if not called else [Path('/media/user/OTHERVOL'), Path('/media/user/OTPKEY')]
        def mount(cmd, **kwargs):
            called.append(cmd)
            return mock.Mock(returncode=0, stdout='Mounted', stderr='')
        with mock.patch.object(usb_drives.sys, 'platform', 'linux'), \
             mock.patch.object(usb_drives, 'mounted_usb_drives', side_effect=mounted), \
             mock.patch.object(usb_drives, '_linux_unmounted_usb_partitions', return_value=[('/dev/sda1', 'OTPKEY')]), \
             mock.patch.object(usb_drives.subprocess, 'run', side_effect=mount), \
             mock.patch.object(usb_drives, '_usb_status', side_effect=lambda p: (p, 'USBを検出しました。')):
            path, info = usb_drives.refresh_usb_mount()
            self.assertEqual(path.name, 'OTPKEY')
            self.assertEqual(len(called), 1)

    def test_multiple_unknown_unmounted_drives_not_automounted(self):
        with mock.patch.object(usb_drives.sys, 'platform', 'linux'), \
             mock.patch.object(usb_drives, 'mounted_usb_drives', return_value=[]), \
             mock.patch.object(usb_drives, '_linux_unmounted_usb_partitions', return_value=[('/dev/sda1',''),('/dev/sdb1','')]), \
             mock.patch.object(usb_drives.subprocess, 'run') as run:
            path, info = usb_drives.refresh_usb_mount()
            self.assertIsNone(path)
            self.assertIn('複数', info)
            run.assert_not_called()

    def test_unmounted_otpkey_mount_failure_is_visible(self):
        with mock.patch.object(usb_drives.sys, 'platform', 'linux'), \
             mock.patch.object(usb_drives, 'mounted_usb_drives', return_value=[]), \
             mock.patch.object(usb_drives, '_linux_unmounted_usb_partitions', return_value=[('/dev/sda1','OTPKEY')]), \
             mock.patch.object(usb_drives.subprocess, 'run', return_value=mock.Mock(returncode=1, stderr='USB failure', stdout='')):
            path, info = usb_drives.refresh_usb_mount()
            self.assertIsNone(path)
            self.assertIn('USB failure', info)
