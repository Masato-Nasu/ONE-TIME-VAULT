"""Regression: a 100% label used to be shown *before* the USB fsync."""
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import patch

import crypto_core as c
import folder_core


class FinalSaveStages(TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.dir = Path(temp.name)
        self.usb = self.dir / "usb"
        self.enc = self.dir / "encrypted"
        self.src = self.dir / "source"
        self.dec = self.dir / "decrypted"
        for d in (self.usb, self.enc, self.src, self.dec):
            d.mkdir()

    def test_file_finishing_phases_and_roundtrip(self):
        original = self.src / "test file.txt"
        original.write_bytes(b"hello world" * 900)
        reports = []
        a, k = c.encrypt_file(original, self.enc, self.usb, progress=lambda *v: reports.append(v))
        self.assertTrue(a.exists() and k.exists())
        self.assertIn("USBの鍵を保存中", [x[0] for x in reports])
        self.assertIn("USBとPCの保存を完了中", [x[0] for x in reports])
        self.assertEqual(c.decrypt_auto(a, [self.usb], self.dec)[0].read_bytes(), original.read_bytes())
        self.assertLess([x[0] for x in reports].index('暗号化'), [x[0] for x in reports].index('USBの鍵を保存中'))

    def test_folder_finishing_phases_and_roundtrip(self):
        (self.src / "nested").mkdir()
        (self.src / "nested" / "data").write_bytes(b'data' * 1000)
        reports = []
        a, k = folder_core.encrypt_folder(self.src, self.enc, self.usb, progress=lambda *v: reports.append(v))
        self.assertIn("USBの鍵を保存中", [x[0] for x in reports])
        self.assertTrue(a.exists() and k.exists())
        out, key = c.decrypt_auto(a, [self.usb], self.dec)
        self.assertEqual(key, k)
        self.assertEqual((out / 'nested' / 'data').read_bytes(), b'data' * 1000)

    def test_not_enough_usb_space_no_partial_files(self):
        (self.src / "big").write_bytes(b'A' * 4096)
        with patch('crypto_core.shutil.disk_usage', return_value=SimpleNamespace(free=128)):
            with self.assertRaisesRegex(c.VaultError, 'USBの空き容量が足りません'):
                c.encrypt_file(self.src / "big", self.enc, self.usb)
        self.assertEqual(list(self.enc.iterdir()), [])
        self.assertEqual(list(self.usb.iterdir()), [])

    def test_not_enough_space_in_folder_no_partial_files(self):
        (self.src / "big").write_bytes(b'A' * 4096)
        with patch('crypto_core.shutil.disk_usage', return_value=SimpleNamespace(free=128)):
            with self.assertRaisesRegex(c.VaultError, 'USBの空き容量が足りません'):
                folder_core.encrypt_folder(self.src, self.enc, self.usb)
        self.assertEqual(list(self.enc.iterdir()), [])
        self.assertEqual(list(self.usb.iterdir()), [])
