"""Regression checks for desktop-only plumbing; no USB or live tray required."""
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import instance_ipc


class IPCChecks(unittest.TestCase):
    def test_menu_launch_raises_existing_instance(self):
        with tempfile.TemporaryDirectory() as td:
            with mock.patch.object(Path, 'home', return_value=Path(td)):
                first, forwarded = instance_ipc.acquire_or_forward()
                try:
                    self.assertFalse(forwarded)
                    self.assertIsNotNone(first)
                    second, forwarded = instance_ipc.acquire_or_forward('decrypt')
                    self.assertTrue(forwarded)
                    self.assertIsNone(second)
                    self.assertEqual(first.poll(), ['decrypt'])
                finally:
                    first.close()
                self.assertFalse((Path(td) / '.cache/one-time-vault/ui.sock').exists())

    def test_stale_socket_recovered(self):
        import socket
        with tempfile.TemporaryDirectory() as td:
            with mock.patch.object(Path, 'home', return_value=Path(td)):
                folder = Path(td) / '.cache/one-time-vault'
                folder.mkdir(parents=True)
                sock = socket.socket(socket.AF_UNIX)
                sock.bind(str(folder/'ui.sock'))
                sock.close()
                first, forwarded = instance_ipc.acquire_or_forward()
                self.assertFalse(forwarded)
                first.close()

    def test_asset_sizes(self):
        root = Path(__file__).resolve().parents[1]
        for px in (16, 24, 32, 48, 64, 128, 256, 512):
            with self.subTest(px=px):
                self.assertTrue((root/'assets'/f'one-time-vault-{px}.png').is_file())


if __name__ == '__main__':
    unittest.main()
