#!/usr/bin/env bash
set -euo pipefail
APP="$HOME/.local/share/one-time-vault"
rm -f "$HOME/.local/share/applications/one-time-vault.desktop" "$HOME/.config/autostart/one-time-vault.desktop"
DESKTOP="${XDG_DESKTOP_DIR:-$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")}"
rm -f "$DESKTOP/ONE-TIME VAULT.desktop"
echo 'メニュー登録・自動起動を削除しました。常駐している場合は、アプリから「終了」してください。'
echo "アプリ本体 ($APP) は暗号関連ファイルと混同しないよう、自動削除していません。"
