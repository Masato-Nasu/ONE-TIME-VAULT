"""ONE-TIME VAULT — file or whole-folder offline desktop encryption UI.

Windows, macOS, Linux. No web calls or third party packages.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import time

from crypto_core import (Cancelled, VaultError, decrypt_auto, decrypt_file,
                         encrypt_file)
from usb_drives import assert_writable_dir, choose_default_usb, desktop_folder, mounted_usb_drives, refresh_usb_mount
from folder_core import encrypt_folder
from i18n import APP_VERSION, load_language, save_language, t, phase_text, translate_external


def run_cli(argv):
    parser = argparse.ArgumentParser(description="ONE-TIME VAULT — オフライン暗号化")
    subs = parser.add_subparsers(dest="command")
    enc = subs.add_parser("encrypt", help="暗号化")
    enc.add_argument("file", help="ファイルまたはフォルダ")
    enc.add_argument("--cipher-dir", required=True)
    enc.add_argument("--key-dir", required=True)
    enc.add_argument("--random", choices=("os", "hardware-mix"), default="os")
    enc.add_argument("--exclude-dev", action="store_true", help="再生成可能な開発用フォルダを除外")
    dec = subs.add_parser("decrypt", help="復元")
    dec.add_argument("cipher")
    dec.add_argument("key", nargs="?", help="鍵ファイル（省略時は --usb の中を自動検索）")
    dec.add_argument("--usb", help="鍵を探すUSBフォルダ")
    dec.add_argument("--out", required=True)
    opts = parser.parse_args(argv)
    if not opts.command:
        parser.print_help()
        return 2
    try:
        if opts.command == "encrypt":
            ignored = []
            if Path(opts.file).is_dir():
                a, b = encrypt_folder(opts.file, opts.cipher_dir, opts.key_dir,
                                      opts.random, skipped=ignored,
                                      exclude_generated=opts.exclude_dev)
            else:
                a, b = encrypt_file(opts.file, opts.cipher_dir, opts.key_dir, opts.random)
            print("暗号ファイル:", a)
            print("鍵ファイル:", b)
            if ignored:
                print(f"注意: リンク・特殊ファイル・指定された開発環境 {len(ignored)} 件を除外しました。")
                for rel in ignored[:6]:
                    print("除外:", repr(rel))
                if len(ignored) > 6:
                    print(f"ほか {len(ignored) - 6} 件を除外")
        elif opts.key:
            print("復元ファイル:", decrypt_file(opts.cipher, opts.key, opts.out))
        else:
            root = Path(opts.usb) if opts.usb else choose_default_usb()
            if root is None:
                raise VaultError("鍵を保存したUSBを挿すか、--usb で指定してください。")
            result, key = decrypt_auto(opts.cipher, [root], opts.out)
            print("復元ファイル:", result, "\n検出した鍵:", key)
        return 0
    except (VaultError, OSError, ValueError) as exc:
        print("エラー:", exc, file=sys.stderr)
        return 1


def open_folder(folder: Path):
    if sys.platform == "win32":
        os.startfile(str(folder))
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(folder)])
    else:
        subprocess.Popen(["xdg-open", str(folder)])


def run_gui(start_hidden=False):
    # Menu / autostart must not create two independent processes at once.
    # The IPC channel carries UI requests only; encrypted content never passes it.
    from instance_ipc import acquire_or_forward
    from tray_support import create_icon, ASSET_DIR
    single_instance, forwarded = acquire_or_forward('show')
    if forwarded:
        return 0
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
    except ImportError:
        print("GUIに tkinter が必要です。Linux Mint: sudo apt install python3-tk", file=sys.stderr)
        return 1

    BG, WHITE, INK, MUTED = "#F6F7F8", "#FFFFFF", "#19242C", "#586871"
    LINE, ACCENT, GOOD = "#DAE0E4", "#1D303D", "#176E62"
    root = tk.Tk()
    root.title(f"ONE-TIME VAULT v{APP_VERSION}")
    root.geometry("740x480")
    root.minsize(560, 345)
    root.configure(bg=BG)
    try:
        _icon_photo = tk.PhotoImage(file=str(ASSET_DIR / 'one-time-vault-64.png'))
        root.iconphoto(True, _icon_photo)
    except (tk.TclError, OSError):
        pass
    ff = "Helvetica Neue" if sys.platform == "darwin" else "Segoe UI" if sys.platform == "win32" else "DejaVu Sans"
    regular, bold, tiny = (ff, 10), (ff, 10, "bold"), (ff, 9)
    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure("OTV.Horizontal.TProgressbar", background=GOOD, troughcolor=LINE, borderwidth=0, thickness=6)

    language = {"value": load_language()}
    def tr(msgid, **kwargs):
        return t(language["value"], msgid, **kwargs)

    outer = tk.Frame(root, bg=BG, padx=20, pady=12)
    outer.pack(fill="both", expand=True)
    # Pack the footer FIRST. Tk reserves its height before allocating space to
    # body text; on small screens, the primary action can never be clipped.
    footer = tk.Frame(outer, bg=BG)
    footer.pack(side="bottom", fill="x", pady=(8, 0))
    heading = tk.Frame(outer, bg=BG)
    heading.pack(fill="x")
    language_switch = tk.Frame(heading, bg=BG)
    language_switch.pack(side="right", pady=(3, 0))
    tk.Label(heading, text="ONE-TIME VAULT", bg=BG, fg=INK, anchor="w", font=(ff, 21, "bold")).pack(side="left", fill="x", expand=True)
    tagline = tk.Label(outer, text=tr("tagline"), bg=BG, fg=MUTED, anchor="w", font=regular)
    tagline.pack(fill="x", pady=(1, 9))

    mode = tk.StringVar(value="encrypt")
    pathvars = {"encrypt": tk.StringVar(), "decrypt": tk.StringVar()}
    usb_override = {"path": None}
    usb_refreshing = {"value": False}
    usb_hint = tk.StringVar()
    message = tk.StringVar(value=tr("status_idle"))
    progress_value = tk.DoubleVar(value=0)
    events = queue.Queue()
    stop_event = threading.Event()
    busy = {"value": False, "last": 0.0}
    tabbuttons = []
    langbuttons = {}
    status_key = {"value": "status_idle"}
    tray_commands = queue.Queue()
    tray_icon = None

    def button(parent, title, callback, *, primary=False):
        return tk.Button(parent, text=title, command=callback, font=bold if primary else regular,
                         bg=ACCENT if primary else WHITE, fg=WHITE if primary else INK,
                         activebackground="#314857" if primary else BG,
                         activeforeground=WHITE if primary else INK,
                         relief="flat" if primary else "solid", bd=0 if primary else 1,
                         highlightthickness=0, padx=14, pady=7, cursor="hand2")

    rowtabs = tk.Frame(outer, bg=BG)
    rowtabs.pack(fill="x", pady=(0, 8))

    body = tk.Frame(outer, bg=WHITE, highlightbackground=LINE, highlightthickness=1, padx=14, pady=10)
    body.pack(fill="both", expand=True)
    source_label = tk.Label(body, text=tr("source"), bg=WHITE, fg=INK, font=bold, anchor="w")
    source_label.pack(fill="x", pady=(0, 7))
    select_row = tk.Frame(body, bg=WHITE)
    select_row.pack(fill="x")
    chosen = tk.Entry(select_row, relief="solid", bd=1, font=regular,
                      textvariable=pathvars["encrypt"], bg="#FBFCFC", fg=INK)
    chosen.pack(side="left", fill="x", expand=True, ipady=7)

    def select_file():
        if busy["value"]:
            return
        start = desktop_folder() / "暗号化" if mode.get() == "decrypt" else desktop_folder()
        result = filedialog.askopenfilename(parent=root, initialdir=str(start if start.is_dir() else Path.home()),
                                            title=tr("choose_cipher_file") if mode.get() == "decrypt" else tr("choose_encrypt_file"),
                                            filetypes=[(tr("all_files"), "*")])
        if result:
            pathvars[mode.get()].set(result)

    def select_directory():
        if busy["value"]:
            return
        start = desktop_folder()
        result = filedialog.askdirectory(parent=root, initialdir=str(start if start.is_dir() else Path.home()),
                                         title=tr("choose_folder"), mustexist=True)
        if result:
            pathvars["encrypt"].set(result)

    pick = button(select_row, tr("file"), select_file)
    pick.pack(side="left", padx=(8, 0))
    pick_folder = button(select_row, tr("folder"), select_directory)
    pick_folder.pack(side="left", padx=(8, 0))

    usb_line = tk.Frame(body, bg=WHITE)
    usb_line.pack(fill="x", pady=(10, 0))
    usb_label = tk.Label(usb_line, text=tr("key_usb"), bg=WHITE, fg=INK, font=bold)
    usb_label.pack(side="left")

    def update_usb():
        if busy["value"]:
            return
        if usb_override["path"] and Path(usb_override["path"]).is_dir():
            selected = Path(usb_override["path"])
        else:
            usb_override["path"] = None
            selected = choose_default_usb()
        usb_hint.set(str(selected) if selected else tr("no_usb"))

    def manual_usb():
        if busy["value"]:
            return
        path = filedialog.askdirectory(parent=root, title=tr("choose_usb_folder"), mustexist=True)
        if path:
            usb_override["path"] = Path(path)
            update_usb()

    def refresh_usb():
        if busy["value"]:
            message.set(tr("busy_refresh"))
            return
        if usb_refreshing["value"]:
            return
        usb_refreshing["value"] = True
        usb_override["path"] = None
        refresh_button.configure(state="disabled", text=tr("checking"))
        message.set(tr("usb_check"))

        def worker():
            try:
                path, explanation = refresh_usb_mount()
                events.put(("usb-refresh", path, explanation))
            except Exception as exc:
                events.put(("usb-refresh", None, "USBの検出に失敗しました: " + str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    select_usb_button = button(usb_line, tr("select_usb"), manual_usb)
    select_usb_button.pack(side="right", padx=(7, 0))
    refresh_button = button(usb_line, tr("refresh"), refresh_usb)
    refresh_button.pack(side="right")
    tk.Label(body, textvariable=usb_hint, bg=WHITE, fg=MUTED, font=tiny,
             anchor="w", justify="left", wraplength=620).pack(fill="x", pady=(6, 0))

    hw_enabled = tk.BooleanVar(value=False)
    supports_hw = sys.platform.startswith("linux") and Path("/dev/hwrng").exists() and os.access("/dev/hwrng", os.R_OK)
    hardware_toggle = tk.Checkbutton(body, text=tr("hardware"), variable=hw_enabled,
                                     bg=WHITE, fg=MUTED, activebackground=WHITE,
                                     font=tiny, selectcolor=WHITE)
    if supports_hw:
        hardware_toggle.pack(fill="x", anchor="w", pady=(12, 0))
    skip_generated = tk.BooleanVar(value=False)
    generated_toggle = tk.Checkbutton(footer, text=tr("skip_development"),
                                      variable=skip_generated, bg=WHITE, fg=MUTED,
                                      activebackground=WHITE, font=tiny, selectcolor=WHITE)
    folder_hint = tk.StringVar()
    folder_label = tk.Label(body, textvariable=folder_hint, bg=WHITE, fg=MUTED, font=tiny,
                            anchor="w", justify="left", wraplength=620)
    folder_label.pack(fill="x", pady=(9, 0))

    # Dock footer at the bottom, always visible on smaller displays.
    progress_widget = ttk.Progressbar(footer, variable=progress_value, maximum=100, style="OTV.Horizontal.TProgressbar")
    progress_widget.pack(fill="x", pady=(0, 7))
    tk.Label(footer, textvariable=message, bg=BG, fg=MUTED, font=tiny,
             anchor="w", justify="left").pack(fill="x", pady=(0, 8))
    control_row = tk.Frame(footer, bg=BG)
    control_row.pack(fill="x")

    def enable_all(value):
        busy["value"] = not value
        go.configure(state="normal" if value else "disabled")
        cancel_button.configure(state="disabled" if value else "normal")
        pick.configure(state="normal" if value else "disabled")
        pick_folder.configure(state="normal" if value else "disabled")
        chosen.configure(state="normal" if value else "disabled")
        for b in tabbuttons:
            b.configure(state="normal" if value else "disabled")

    def run_task():
        if busy["value"]:
            return
        if usb_refreshing["value"]:
            message.set(tr("wait_usb_refresh"))
            return
        source = pathvars[mode.get()].get().strip()
        if not source or not (Path(source).is_file() or (mode.get() == "encrypt" and Path(source).is_dir())):
            messagebox.showwarning(tr("warn_choose_title"), tr("warn_choose"), parent=root)
            return
        # Recheck selection at execution time; the user may have inserted a USB
        # after opening the app without pressing Refresh.
        if usb_hint.get() in (t("ja", "no_usb"), t("en", "no_usb")):
            update_usb()
        usb_path = Path(usb_hint.get())
        if not usb_path.is_dir() or usb_hint.get() in (t("ja", "no_usb"), t("en", "no_usb")):
            messagebox.showwarning(tr("warn_usb_title"), tr("warn_usb"), parent=root)
            return
        current = mode.get()
        selected_random = "hardware-mix" if hw_enabled.get() and supports_hw else "os"
        selected_exclude_generated = skip_generated.get()
        if current == "encrypt":
            if not messagebox.askokcancel(tr("confirm_title"), tr("confirm_encrypt"), parent=root):
                return
        stop_event.clear()
        progress_value.set(0)
        message.set(tr("working"))
        enable_all(False)
        busy["last"] = 0.0

        def report(phase, done, total):
            now = time.monotonic()
            if phase == "USBの鍵を段階保存中" or now - busy["last"] > 0.2 or (total > 0 and done == total):
                busy["last"] = now
                events.put(("progress", phase, done, total))

        def job():
            try:
                desktop = desktop_folder()
                desktop.mkdir(parents=True, exist_ok=True)
                if current == "encrypt":
                    assert_writable_dir(usb_path)
                    out = desktop / "暗号化"
                    out.mkdir(parents=True, exist_ok=True)
                    if out.resolve() == usb_path.resolve():
                        raise VaultError("暗号ファイルと鍵の保存先が同じです。")
                    ignored = []
                    if Path(source).is_dir():
                        c, k = encrypt_folder(source, out, usb_path, mode=selected_random,
                                              progress=report, cancel=stop_event, skipped=ignored,
                                              exclude_generated=selected_exclude_generated)
                    else:
                        c, k = encrypt_file(source, out, usb_path, mode=selected_random,
                                            progress=report, cancel=stop_event)
                    events.put(("success", current, c, k, ignored))
                else:
                    out = desktop / "復号"
                    out.mkdir(parents=True, exist_ok=True)
                    restored, key = decrypt_auto(source, [usb_path], out, report, stop_event)
                    events.put(("success", current, restored, key))
            except Cancelled as exc:
                events.put(("cancelled", str(exc)))
            except (VaultError, OSError, ValueError) as exc:
                events.put(("error", str(exc)))
            except Exception as exc:
                events.put(("error", "予期しないエラー: " + str(exc)))
        threading.Thread(target=job, daemon=True).start()

    go = button(control_row, tr("encrypt_action"), run_task, primary=True)
    go.pack(side="left")
    cancel_button = button(control_row, tr("cancel"), stop_event.set)
    cancel_button.pack(side="left", padx=(8, 0))
    cancel_button.configure(state="disabled")

    def switch(which):
        if busy["value"]:
            return
        mode.set(which)
        chosen.configure(textvariable=pathvars[which])
        go.configure(text=tr("encrypt_action") if which == "encrypt" else tr("decrypt_action"))
        pick.configure(text=tr("file") if which == "encrypt" else tr("choose"))
        if which == "encrypt":
            pick_folder.pack(side="left", padx=(8, 0))
        else:
            pick_folder.pack_forget()
        if which == "encrypt":
            generated_toggle.pack(fill="x", anchor="w", pady=(0, 6), before=progress_widget)
        else:
            generated_toggle.pack_forget()
        if supports_hw:
            if which == "encrypt":
                hardware_toggle.pack(fill="x", anchor="w", pady=(12, 0), before=folder_label)
            else:
                hardware_toggle.pack_forget()
        folder_hint.set(tr("encrypt_help") if which == "encrypt" else tr("decrypt_help"))
        for i, b in enumerate(tabbuttons):
            active = (i == 0 and which == "encrypt") or (i == 1 and which == "decrypt")
            b.configure(bg=ACCENT if active else WHITE, fg=WHITE if active else INK)
        message.set(tr("status_idle"))
        status_key["value"] = "status_idle"
        progress_value.set(0)

    for which in ("encrypt", "decrypt"):
        widget = button(rowtabs, f"  {tr(which)}  ", lambda m=which: switch(m))
        widget.pack(side="left", padx=(0, 8))
        tabbuttons.append(widget)
    def change_language(target):
        if target == language["value"]:
            return
        language["value"] = target
        try:
            save_language(target)
        except OSError:
            # Lack of permission to write settings must not block encryption.
            pass
        refresh_translations()

    def refresh_translations():
        tagline.configure(text=tr("tagline"))
        source_label.configure(text=tr("source"))
        pick_folder.configure(text=tr("folder"))
        usb_label.configure(text=tr("key_usb"))
        select_usb_button.configure(text=tr("select_usb"))
        refresh_button.configure(text=tr("checking" if usb_refreshing["value"] else "refresh"))
        generated_toggle.configure(text=tr("skip_development"))
        hardware_toggle.configure(text=tr("hardware"))
        cancel_button.configure(text=tr("cancel"))
        quit_button.configure(text=tr("quit"))
        for which, widget in zip(("encrypt", "decrypt"), tabbuttons):
            widget.configure(text=f"  {tr(which)}  ")
        for lang, widget in langbuttons.items():
            selected = lang == language["value"]
            widget.configure(bg=ACCENT if selected else WHITE,
                             fg=WHITE if selected else INK)
        if usb_hint.get() in (t("ja", "no_usb"), t("en", "no_usb")):
            usb_hint.set(tr("no_usb"))
        current = mode.get()
        go.configure(text=tr("encrypt_action") if current == "encrypt" else tr("decrypt_action"))
        pick.configure(text=tr("file") if current == "encrypt" else tr("choose"))
        folder_hint.set(tr("encrypt_help" if current == "encrypt" else "decrypt_help"))
        # Localize the idle message without interrupting an in-progress operation.
        if not busy["value"] and not usb_refreshing["value"]:
            message.set(tr("status_idle"))
        # pystray evaluates its translated menu labels when opened.
        if tray_icon is not None:
            try:
                tray_icon.update_menu()
            except Exception:
                pass

    for lang, label in (("ja", "日本語"), ("en", "EN")):
        widget = button(language_switch, label, lambda target=lang: change_language(target))
        widget.configure(font=tiny, padx=7, pady=4)
        widget.pack(side="left", padx=(3, 0))
        langbuttons[lang] = widget
    # Widgets used by refresh_translations are finished below.

    def show_window(which=None):
        root.deiconify()
        root.lift()
        root.focus_force()
        if which in ('encrypt', 'decrypt'):
            switch(which)

    def quit_app():
        if busy["value"]:
            show_window()
            messagebox.showwarning(tr("busy_title"), tr("busy_quit"), parent=root)
            return
        root.destroy()

    # The quit action stays accessible even if a Linux tray backend supports
    # only a default click and no popup menu (Xorg backend).
    quit_button = button(control_row, tr("quit"), quit_app)
    quit_button.pack(side="right")
    switch("encrypt")
    refresh_translations()
    update_usb()

    def drain():
        nonlocal tray_icon
        # A tray backend that dies unexpectedly must not leave an invisible UI.
        if tray_icon is not None and not tray_icon.is_alive():
            tray_icon = None
            root.deiconify()
            message.set(tr("tray_failed"))
        try:
            while True:
                command = tray_commands.get_nowait()
                if command in ('show', 'encrypt', 'decrypt'):
                    show_window(None if command == 'show' else command)
                elif command == 'quit':
                    quit_app()
        except queue.Empty:
            pass
        if single_instance is not None:
            try:
                for command in single_instance.poll():
                    if command in ('show', 'encrypt', 'decrypt'):
                        show_window(None if command == 'show' else command)
            except OSError:
                pass
        try:
            while True:
                item = events.get_nowait()
                if item[0] == "usb-refresh":
                    _, usb_path, explanation = item
                    usb_refreshing["value"] = False
                    refresh_button.configure(state="normal", text=tr("refresh"))
                    usb_hint.set(str(usb_path) if usb_path else tr("no_usb"))
                    message.set(translate_external(language["value"], explanation))
                elif item[0] == "progress":
                    _, phase, done, total = item
                    if total == 0:
                        progress_value.set(0)
                        message.set(tr("checking_items", count=done))
                    else:
                        if phase in ("暗号化", "復元", "完全性の確認", "USBの鍵を段階保存中"):
                            # 100% means *durably finished*, not just XOR work.
                            # fsyncing a large key to a slow USB can take minutes.
                            pct = min(99.0, done / total * 99.0)
                            progress_value.set(pct)
                            message.set((tr("usb_write_progress", pct=pct)
                                         if phase == "USBの鍵を段階保存中"
                                         else tr("work_progress", phase=phase_text(language["value"], phase), pct=pct)))
                        else:
                            progress_value.set(99)
                            message.set(tr("finish_phase", phase=phase_text(language["value"], phase)))
                elif item[0] == "success":
                    _, which, path, key, *extra = item
                    ignored = extra[0] if extra else []
                    enable_all(True)
                    progress_value.set(100)
                    message.set(tr("finished", name=path.name) + (tr("skipped_status", count=len(ignored)) if ignored else ""))
                    detail = tr("result_detail", label=tr("result_cipher" if which == "encrypt" else "result_restored"), path=path, key=key)
                    if ignored:
                        preview = "\n".join("・" + x for x in ignored[:5])
                        if len(ignored) > 5:
                            preview += "\n" + tr("more_skipped", count=len(ignored) - 5)
                        detail += tr("skipped_detail", count=len(ignored), names=preview)
                    messagebox.showinfo(tr("saved_skip_title" if ignored else "saved_title") if which == "encrypt" else tr("restored_title"),
                                        detail, parent=root)
                    try:
                        open_folder(path.parent)
                    except OSError:
                        pass
                elif item[0] == "cancelled":
                    enable_all(True)
                    progress_value.set(0)
                    message.set(tr("cancelled"))
                elif item[0] == "error":
                    enable_all(True)
                    progress_value.set(0)
                    message.set(tr("failed"))
                    messagebox.showerror(tr("error_title"), translate_external(language["value"], item[1]), parent=root)
        except queue.Empty:
            pass
        if root.winfo_exists():
            root.after(100, drain)

    def on_close():
        # Closing the window hides it only when a working tray is available.
        # Otherwise exiting is safer than leaving an invisible process running.
        if tray_icon is not None:
            root.withdraw()
            return
        if busy["value"]:
            messagebox.showinfo(tr("busy_title"), tr("busy_close"), parent=root)
            return
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    tray_icon = create_icon(tray_commands, language_getter=lambda: language["value"])
    if start_hidden and tray_icon is not None:
        root.withdraw()
    else:
        root.deiconify()
    root.after(100, drain)
    try:
        root.mainloop()
    finally:
        if tray_icon is not None:
            try:
                tray_icon.stop()
            except Exception:
                pass
        if single_instance is not None:
            single_instance.close()
    return 0


if __name__ == "__main__":
    arguments = sys.argv[1:]
    if not arguments:
        sys.exit(run_gui())
    elif arguments == ['--background']:
        sys.exit(run_gui(start_hidden=True))
    else:
        sys.exit(run_cli(arguments))
