"""Optional system tray support; callbacks are queued for the Tk main thread.

The Linux installation uses pystray's Xorg backend (works independently of GTK).
If the backend is absent, the ordinary Tk window stays usable.
"""
from __future__ import annotations

import os
from pathlib import Path
import queue
import sys
import threading

ASSET_DIR = Path(__file__).resolve().parent / 'assets'


class TrayHandle:
    def __init__(self, icon, thread):
        self.icon, self.thread = icon, thread

    def is_alive(self):
        return self.thread.is_alive()

    def stop(self):
        self.icon.stop()


def create_icon(commands: queue.Queue, language_getter=None):
    """Start tray in a daemon thread on Linux/Windows. Return icon or None."""
    try:
        current_lang = language_getter if language_getter else (lambda: "ja")
        def tray_label(ja, en):
            return lambda _: en if current_lang() == "en" else ja

        if sys.platform.startswith('linux') and os.environ.get('DISPLAY'):
            # GTK/appindicator event loops cannot be safely detached from Tk.
            # On Linux Mint X11, the Xorg backend allows single-click to open.
            os.environ.setdefault('PYSTRAY_BACKEND', 'xorg')
        import pystray
        from PIL import Image
        menu = pystray.Menu(
            pystray.MenuItem(tray_label('ONE-TIME VAULT を開く', 'Open ONE-TIME VAULT'), lambda *_: commands.put('show'), default=True),
            pystray.MenuItem(tray_label('暗号化', 'Encrypt'), lambda *_: commands.put('encrypt')),
            pystray.MenuItem(tray_label('復号', 'Decrypt'), lambda *_: commands.put('decrypt')),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem(tray_label('終了', 'Quit'), lambda *_: commands.put('quit')),
        )
        icon = pystray.Icon('one-time-vault', Image.open(ASSET_DIR / 'one-time-vault-64.png'), 'ONE-TIME VAULT', menu)
        t = threading.Thread(target=icon.run, name='one-time-vault-tray', daemon=True)
        t.start()
        # Xorg requires an X11 display; if unavailable backend will fail on run.
        # Poll once for early startup failures so GUI can stay visible.
        t.join(timeout=0.5)
        if not t.is_alive():
            return None
        return TrayHandle(icon, t)
    except Exception as exc:
        print('常駐アイコンを開始できません:', exc, file=sys.stderr)
        return None
