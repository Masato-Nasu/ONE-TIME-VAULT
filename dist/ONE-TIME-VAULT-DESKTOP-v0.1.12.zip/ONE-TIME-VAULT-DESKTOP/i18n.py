"""Presentation-only Japanese/English strings. Does not modify encrypted file formats.

Application preferences contain only the UI language, never any cryptographic data.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import sys

APP_VERSION = '0.1.12'

UI = {
    'ja': {
        'tagline': '暗号化データはデスクトップ、鍵はUSBへ。',
        'encrypt': '暗号化', 'decrypt': '復号',
        'source': 'ファイル / フォルダ', 'file': 'ファイル', 'folder': 'フォルダ',
        'choose': '選択', 'key_usb': '鍵のUSB', 'select_usb': 'USBを選ぶ',
        'refresh': '再検出', 'checking': '確認中…',
        'no_usb': 'USBを挿してください', 'choose_encrypt_file': 'ファイルを選択',
        'choose_cipher_file': '暗号ファイルを選択', 'choose_folder': '暗号化するフォルダを選択',
        'choose_usb_folder': 'USBのフォルダを指定', 'all_files': 'すべてのファイル',
        'hardware': 'ハードウェア乱数を混ぜる（低速）',
        'skip_development': '開発用フォルダを除外（.venv など・任意）',
        'status_idle': 'ファイルは外部へ送信されません。',
        'encrypt_action': '暗号化する', 'decrypt_action': '復号する',
        'cancel': '中止', 'quit': '終了',
        'encrypt_help': 'ファイルもフォルダもまとめて暗号化できます。\n暗号ファイル → デスクトップ / 暗号化    鍵 → USB',
        'decrypt_help': 'ファイル・フォルダ → デスクトップ / 復号\n鍵はUSBの中から自動で探します（名前を変更しても大丈夫）。',
        'busy_refresh': '暗号化・復号の処理中は再検出できません。完了までUSBを抜かないでください。',
        'usb_check': 'USBの接続を確認しています…',
        'refresh_failed': 'USBの検出に失敗しました: {detail}',
        'wait_usb_refresh': 'USBの再検出が終わってから操作してください。',
        'warn_choose_title': '選択してください',
        'warn_choose': '暗号化するファイル・フォルダ、または復号するファイルを選んでください。',
        'warn_usb_title': 'USBがありません',
        'warn_usb': '鍵を保存したいUSBを挿し、「再検出」を押してください。',
        'confirm_title': '暗号化',
        'confirm_encrypt': '鍵をUSBに保存します。鍵がないと復元できません。\n\n続けますか？',
        'working': '処理中…',
        'same_location': '暗号ファイルと鍵の保存先が同じです。',
        'unexpected': '予期しないエラー: {detail}',
        'checking_items': 'フォルダを確認中… {count:,} 項目',
        'usb_write_progress': 'USBに鍵を書き込み中  {pct:.1f}%（抜かないでください）',
        'work_progress': '{phase}中  {pct:.1f}%',
        'finish_phase': '{phase}… USBは抜かないでください',
        'finished': '完了: {name}',
        'skipped_status': '（除外 {count} 件）',
        'result_cipher': '暗号化ファイル', 'result_restored': '復号ファイル',
        'result_detail': '{label}:\n{path}\n\n鍵:\n{key}',
        'more_skipped': '・ほか {count} 件',
        'skipped_detail': '\n\n注意: リンク・特殊ファイル・選択した開発用フォルダ {count} 件は含まれていません。\n{names}\n復元すると、これらは戻りません。',
        'saved_skip_title': '保存しました（一部除外）',
        'saved_title': '保存しました', 'restored_title': '復元しました',
        'cancelled': '中止しました。', 'failed': '失敗しました。', 'error_title': '処理できませんでした',
        'busy_title': '処理中',
        'busy_quit': '暗号化・復号の完了を待つか、中止してから終了してください。',
        'busy_close': '処理を中止してから閉じてください。',
        'tray_failed': '通知領域の起動に失敗しました。通常のウィンドウで動作します。',
    },
    'en': {
        'tagline': 'Encrypted data on your desktop. Keys on your USB.',
        'encrypt': 'Encrypt', 'decrypt': 'Decrypt',
        'source': 'File / Folder', 'file': 'File', 'folder': 'Folder',
        'choose': 'Select', 'key_usb': 'Key USB', 'select_usb': 'Select USB',
        'refresh': 'Refresh', 'checking': 'Checking…',
        'no_usb': 'Insert a USB drive', 'choose_encrypt_file': 'Select a file',
        'choose_cipher_file': 'Select an encrypted file', 'choose_folder': 'Select a folder to encrypt',
        'choose_usb_folder': 'Select the USB folder', 'all_files': 'All files',
        'hardware': 'Mix in hardware randomness (slow)',
        'skip_development': 'Exclude development folders (.venv, etc.; optional)',
        'status_idle': 'Your files are never uploaded.',
        'encrypt_action': 'Encrypt', 'decrypt_action': 'Decrypt',
        'cancel': 'Cancel', 'quit': 'Quit',
        'encrypt_help': 'Encrypt a file or an entire folder.\nEncrypted file → Desktop / 暗号化    Key → USB',
        'decrypt_help': 'Restored file/folder → Desktop / 復号\nThe matching key is found on USB, even if renamed.',
        'busy_refresh': 'USB refresh is unavailable during encryption or decryption. Keep the USB connected.',
        'usb_check': 'Checking connected USB drives…',
        'refresh_failed': 'USB detection failed: {detail}',
        'wait_usb_refresh': 'Wait for USB detection to finish before continuing.',
        'warn_choose_title': 'Select a file',
        'warn_choose': 'Select a file or folder to encrypt, or an encrypted file to decrypt.',
        'warn_usb_title': 'No USB drive',
        'warn_usb': 'Insert the USB drive that stores your keys, then click Refresh.',
        'confirm_title': 'Encrypt',
        'confirm_encrypt': 'The key will be saved to your USB drive. Without this key, you cannot restore the data.\n\nContinue?',
        'working': 'Working…',
        'same_location': 'The encrypted data and key cannot be stored in the same folder.',
        'unexpected': 'Unexpected error: {detail}',
        'checking_items': 'Scanning folder… {count:,} items',
        'usb_write_progress': 'Writing key to USB  {pct:.1f}% (do not disconnect)',
        'work_progress': '{phase}  {pct:.1f}%',
        'finish_phase': '{phase}… Do not disconnect the USB',
        'finished': 'Finished: {name}',
        'skipped_status': ' ({count} items skipped)',
        'result_cipher': 'Encrypted file', 'result_restored': 'Restored file',
        'result_detail': '{label}:\n{path}\n\nKey:\n{key}',
        'more_skipped': '• {count} more items',
        'skipped_detail': '\n\nNote: {count} links, special items or selected development folders were excluded.\n{names}\nExcluded items will not be restored.',
        'saved_skip_title': 'Saved (some items excluded)',
        'saved_title': 'Saved', 'restored_title': 'Restored',
        'cancelled': 'Cancelled.', 'failed': 'Failed.', 'error_title': 'Unable to complete',
        'busy_title': 'In progress',
        'busy_quit': 'Wait for encryption/decryption to finish, or cancel before quitting.',
        'busy_close': 'Cancel the operation before closing.',
        'tray_failed': 'The tray icon failed to start. The app will stay visible.',
    },
}

PHASES_EN = {
    '確認': 'Scanning', '暗号化': 'Encrypting', '復元': 'Restoring', '復号': 'Decrypting',
    '完全性の確認': 'Verifying integrity', 'USBの鍵を段階保存中': 'Writing key to USB',
    'USBの鍵を保存中': 'Saving USB key', 'PCの暗号ファイル保存を確定中': 'Finalizing encrypted file',
    '保存したファイルを確定中': 'Finalizing saved files', 'USBとPCの保存を完了中': 'Finishing USB and desktop writes',
}

# Messages emitted by low-level modules. Preserve their exact Japanese wording
# internally to avoid accidentally changing error-handling conditions.
ERROR_EN = {
    '操作を中止しました。': 'Operation cancelled.',
    '暗号データと鍵の長さが一致しません。': 'The ciphertext and key lengths do not match.',
    '乱数モードが不正です。': 'Invalid random mode.',
    'ハードウェア混合モードはLinuxのみ対応です。': 'Hardware random mixing is supported on Linux only.',
    '/dev/hwrng を読み取れません。OS乱数モードをお使いください。': 'Cannot read /dev/hwrng. Use OS randomness.',
    'ハードウェア乱数の取得に失敗しました。暗号化を中止します。': 'Hardware random-number generation failed. Encryption stopped.',
    'ハードウェア乱数が途中で途切れました。': 'Hardware randomness stopped unexpectedly.',
    '復元先のファイル名が不正です。': 'Invalid restored filename.',
    'ファイル名に使用できない文字があります。': 'The filename contains unsupported characters.',
    '復元先で使用できないファイル名です。': 'This filename cannot be used at the restore destination.',
    '同名のファイルが多すぎます。保存先を整理してください。': 'Too many files have the same name. Clean up the destination.',
    '暗号ファイルの形式が不正です。': 'Invalid encrypted-file format.',
    'ONE-TIME VAULT の暗号ファイルではありません。': 'This is not a ONE-TIME VAULT encrypted file.',
    '暗号ファイルのサイズが不正です。': 'Invalid encrypted-file size.',
    '暗号ファイルを読み取れません。': 'Cannot read the encrypted file.',
    'USB内に対応する鍵がありません。鍵が保存されたUSBを挿してください。': 'No matching key was found on the USB. Insert the USB containing the key.',
    '対応する鍵が見つかりましたが、復元できませんでした。鍵や暗号ファイルが破損している可能性があります。': 'A matching key was found, but restoration failed. The key or encrypted file may be damaged.',
    '元のファイルが見つかりません。': 'The source file was not found.',
    '暗号ファイルと鍵ファイルは、異なるフォルダーに保存してください。': 'Encrypted data and keys must be stored in different folders.',
    '暗号ファイルと鍵ファイルは別の場所に保存してください。': 'Store encrypted data and keys separately.',
    '対応できる最大サイズを超えています。': 'The file exceeds the supported maximum size.',
    '不明な乱数モードです。': 'Unknown random mode.',
    '読み取り中に元ファイルが変更されました。操作を中止しました。': 'The source file changed during reading. Operation cancelled.',
    '同じIDのファイルが既にあります。': 'A file with the same internal ID already exists.',
    'ファイルのヘッダーが不正です。': 'Invalid file header.',
    'ONE-TIME VAULT のファイルではないか、形式が異なります。': 'Not a ONE-TIME VAULT file or incompatible format.',
    '暗号ファイルと鍵ファイルが一致しません。': 'The encrypted file and key do not match.',
    '乱数方式が不正です。': 'Invalid random-number method.',
    '暗号ファイルの長さが不正です。': 'Invalid encrypted-file length.',
    '鍵ファイルの長さが不正です。': 'Invalid key-file length.',
    '鍵ファイルが壊れています。': 'The key file is damaged.',
    '暗号ファイルまたは鍵ファイルが見つかりません。': 'The encrypted file or key was not found.',
    'ファイルが途中で切れています。': 'The file is truncated.',
    '暗号ファイルが破損または改ざんされています。': 'The encrypted file is damaged or has been modified.',
    '鍵ファイルが破損または改ざんされています。': 'The key file is damaged or has been modified.',
    '暗号化データが短すぎます。': 'The encrypted data is too short.',
    '暗号化されたファイル名の長さが不正です。': 'Invalid encrypted filename length.',
    '暗号化されたファイル名を復元できません。': 'Unable to restore the original filename.',
    '復元先に同名ファイルがあります。別のフォルダーを選択してください。': 'A file with the same name exists at the restore destination. Choose another location.',
    '復元先に同名ファイルがあります。': 'A file with that name already exists in the restore destination.',
    '復元中にファイルが読み取れなくなりました。': 'A file became unreadable during restoration.',
    'フォルダ内のパスが長すぎます。': 'A path inside the folder is too long.',
    '大文字と小文字のみが異なる名前を同じフォルダに保存できません。': 'The destination cannot hold filenames that differ only by letter case.',
    'フォルダ内の項目が多すぎます。': 'There are too many items in this folder.',
    '暗号化するフォルダが見つかりません。': 'The folder to encrypt was not found.',
    '暗号化中にフォルダ内のファイルが変更されました。': 'A file in the folder changed during encryption.',
    'フォルダ内のデータ長が一致しません。': 'The folder data length does not match.',
    '保存先に同名のファイルが存在します。': 'A file with the same name exists in the destination.',
    '暗号ファイルまたは鍵が見つかりません。': 'The encrypted file or key was not found.',
    'これはフォルダ暗号ファイルではありません。': 'This is not an encrypted folder archive.',
    'フォルダの暗号化データが不正です。': 'Invalid encrypted-folder data.',
    '復号中にデータを読み取れません。': 'Cannot read data during decryption.',
    'フォルダ名が不正です。': 'Invalid folder name.',
    'フォルダ名を読み取れません。': 'Cannot read the folder name.',
    'フォルダ暗号ファイルの構造が不正です。': 'Invalid encrypted-folder structure.',
    'フォルダ内の項目が不正です。': 'Invalid item inside the folder.',
    'フォルダ内のファイル名が不正です。': 'Invalid filename inside the folder.',
    'フォルダ内のパスが不正です。': 'Invalid path inside the folder.',
    'フォルダ内のパスが重複しています。': 'Duplicate paths inside the folder.',
    'フォルダ構造が不正です。': 'Invalid folder structure.',
    '暗号ファイルのデータ長が不正です。': 'Invalid encrypted data length.',
    'フォルダ暗号ファイルに余分なデータがあります。': 'Unexpected extra data in the encrypted-folder file.',
    'USBが見つかりません。接続を確認するか「USBを選ぶ」を押してください。': 'No USB drive was found. Check the connection or click Select USB.',
    'USBが複数あります。「USBを選ぶ」で使用するUSBを指定してください。': 'Multiple USB drives were found. Click Select USB to choose one.',
    '接続済み・マウント済みのUSBが見つかりません。挿し直して再検出してください。': 'No mounted USB drive was found. Reconnect it and click Refresh.',
    'USBを自動接続する機能が見つかりません。ファイルマネージャーでUSBを開いて再検出してください。': 'Automatic mounting is unavailable. Open the USB in your file manager, then click Refresh.',
    'USBの接続処理が完了しませんでした。ファイルマネージャーでUSBを開いて確認してください。': 'Mounting the USB did not complete. Check it in your file manager.',
    'USBのマウントは成功しましたが、自動選択できません。「USBを選ぶ」から指定してください。': 'USB mounted successfully but was not selected. Choose it via Select USB.',
    'USBを検出しましたが読み取り専用です。': 'USB detected, but it is read-only.',
    'USBを検出しました。': 'USB detected.',
    'USBの保存先フォルダがありません。': 'The USB destination folder was not found.',
    'USBが読み取り専用です。USBの状態を確認してください。': 'The USB is read-only. Check its status.',
    '接続状態を確認してください。': 'Check the connection.',
    'ファイルマネージャーでUSBを開いて確認してください。': 'Check the USB in your file manager.',
    '対象ファイルを使っているアプリを閉じてから再試行してください。': 'Close the application using the file, then try again.',
    'ファイルを使用しているアプリを閉じてから再試行してください。': 'Close the application using the file, then try again.',
    'ファイルにアクセスできません。': 'Cannot access the file.',
}
PREFIX_EN = {
    '保存先ファイルが既にあります: ': 'Destination file already exists: ',
    'PCの暗号化フォルダの空き容量が足りません。': 'Not enough free space in the desktop encryption folder.',
    '暗号化中に次の項目が変更されました: ': 'This item changed during encryption: ',
    '暗号化中にファイルが変更されました: ': 'A file changed during encryption: ',
    '読み取り中にファイルが変更されました: ': 'The file changed during reading: ',
    '読み取れない項目があります: ': 'Cannot read item: ',
    'フォルダを読み取れません: ': 'Cannot read folder: ',
    'USBをマウントできませんでした: ': 'Could not mount USB: ',
    'USBの検出に失敗しました: ': 'USB detection failed: ',
    '予期しないエラー: ': 'Unexpected error: ',
}


def t(lang: str, msgid: str, **kwargs) -> str:
    return UI.get(lang, UI['ja'])[msgid].format(**kwargs)


def phase_text(lang: str, phase: str) -> str:
    return PHASES_EN.get(phase, phase) if lang == 'en' else phase


def translate_external(lang: str, original: object) -> str:
    """Convert known UI-facing errors from legacy crypto/USB code, without altering it."""
    string = str(original)
    if lang != 'en':
        return string
    if string in ERROR_EN:
        return ERROR_EN[string]
    if string.startswith('USBの空き容量が足りません。'):
        return re.sub(r'鍵には約\s*([\d,.]+) MB 必要ですが、空きは約\s*([\d,.]+) MB です。',
                      r'The key needs about \1 MB; only \2 MB is available.',
                      string.replace('USBの空き容量が足りません。', 'Not enough USB space. '))
    for old, new in PREFIX_EN.items():
        if string.startswith(old):
            return new + translate_external(lang, string[len(old):])
    if string.startswith('暗号ファイルの保存先フォルダーが存在しません: '):
        return 'The encrypted-file destination does not exist: ' + string.split(': ', 1)[1]
    if string.startswith('鍵ファイルの保存先フォルダーが存在しません: '):
        return 'The key destination does not exist: ' + string.split(': ', 1)[1]
    if string.startswith('復元先フォルダーが存在しません: ') or string.startswith('復号先フォルダーが存在しません: '):
        return 'The restore destination does not exist: ' + string.split(': ', 1)[1]
    for old, new in ERROR_EN.items():
        if string.startswith(old + '\n'):
            return new + '\n' + translate_external(lang, string[len(old) + 1:])
    # Explicit known templates that may contain dynamic paths / filenames.
    for old, new in {
        '暗号化中にファイルが変更されました: ': 'A file changed during encryption: ',
        '暗号化中に次の項目が変更されました: ': 'An item changed during encryption: ',
    }.items():
        if old in string:
            string = string.replace(old, new, 1)
    for old, new in ERROR_EN.items():
        if old in string and old not in ('USBを検出しました。',):
            string = string.replace(old, new)
    return string


def config_file() -> Path:
    if sys.platform == 'win32':
        base = Path(os.environ.get('APPDATA', str(Path.home() / 'AppData' / 'Roaming')))
        return base / 'ONE-TIME-VAULT' / 'settings.json'
    if sys.platform == 'darwin':
        return Path.home() / 'Library' / 'Application Support' / 'ONE-TIME-VAULT' / 'settings.json'
    return Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config'))) / 'one-time-vault' / 'settings.json'


def load_language() -> str:
    try:
        value = json.loads(config_file().read_text(encoding='utf-8')).get('language')
        return value if value in UI else 'ja'
    except (OSError, ValueError, TypeError, AttributeError):
        return 'ja'


def save_language(lang: str) -> None:
    if lang not in UI:
        raise ValueError('Unsupported language')
    dest = config_file()
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + '.tmp')
    tmp.write_text(json.dumps({'language': lang}, ensure_ascii=False), encoding='utf-8')
    os.replace(tmp, dest)
