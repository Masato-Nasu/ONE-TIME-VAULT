"""Linux-only single-instance IPC for installed menu and autostart launches.

No file payload ever crosses this socket, only UI commands (show/encrypt/decrypt).
"""
from __future__ import annotations

import os
from pathlib import Path
import socket
import sys


class InstanceServer:
    def __init__(self, socket_path: Path, server: socket.socket):
        self.socket_path, self.server = socket_path, server

    def poll(self):
        results = []
        while True:
            try:
                peer, _ = self.server.accept()
            except BlockingIOError:
                break
            with peer:
                peer.settimeout(.3)
                try:
                    command = peer.recv(80).decode('ascii', 'replace').strip()
                    if command in ('show', 'encrypt', 'decrypt'):
                        results.append(command)
                except (OSError, UnicodeError):
                    pass
        return results

    def close(self):
        self.server.close()
        try:
            self.socket_path.unlink(missing_ok=True)
        except OSError:
            pass


def acquire_or_forward(command='show'):
    if not sys.platform.startswith('linux'):
        return None, False
    directory = Path.home() / '.cache' / 'one-time-vault'
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    directory.chmod(0o700)
    sockpath = directory / 'ui.sock'

    def forward():
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.settimeout(.5)
            client.connect(str(sockpath))
            client.sendall(command.encode('ascii'))

    if sockpath.exists():
        try:
            forward()
            return None, True
        except (ConnectionRefusedError, FileNotFoundError, TimeoutError, OSError):
            # Stale file from previous crash; a fresh bind will be attempted.
            sockpath.unlink(missing_ok=True)

    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        server.bind(str(sockpath))
        sockpath.chmod(0o600)
        server.listen(5)
        server.setblocking(False)
        return InstanceServer(sockpath, server), False
    except OSError:
        server.close()
        # Another concurrent launch likely won the bind race.
        try:
            forward()
            return None, True
        except OSError:
            return None, False
