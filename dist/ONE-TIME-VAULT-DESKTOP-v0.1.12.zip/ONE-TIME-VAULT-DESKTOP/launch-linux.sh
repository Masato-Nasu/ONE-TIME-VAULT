#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"
if [ -x .venv/bin/python ]; then PY=.venv/bin/python; else PY=python3; fi
# The launcher can be launched from the menu without a terminal.
exec "$PY" main.py "$@"
