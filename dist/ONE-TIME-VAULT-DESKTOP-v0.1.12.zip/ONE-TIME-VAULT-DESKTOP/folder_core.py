"""Authenticated, stream-encrypted directory snapshots for ONE-TIME VAULT.

Never creates an unencrypted intermediary archive. The container v1 envelope,
key-matching ID, and v1 files remain compatible with previous releases.
"""
from __future__ import annotations

import hashlib
import hmac
import os
from pathlib import Path
import secrets
import shutil
import stat
import struct
import tempfile

import crypto_core as c

DIR_C = b"OTVD1\0"
DIR_K = b"OTDK1\0"
DIR_SIGNATURE = b"OTV-DIR1"
RECORD = struct.Struct(">BHQ")  # 1 = directory, 2 = regular file; relative name len; file size
COUNT = struct.Struct(">I")
MAX_RECORDS = 1_000_000
MAX_PATH_BYTES = 65535
GENERATED_DIRS = frozenset({".venv", "venv", "__pycache__", "node_modules", ".git", ".mypy_cache", ".pytest_cache"})


def _scan(folder: Path, cancel=None, progress=None, exclude_generated=False):
    """Scan regular contents without following directory links or special files.

    Ignored entries are returned, never silently dropped. No symlink targets are
    dereferenced, including symlinks to directories outside the selected tree.
    """
    entries = []
    skipped = []
    seen_names = set()
    total_data = 0
    examined = 0

    def walk_error(error):
        raise c.VaultError(f"フォルダを読み取れません: {error}")

    for base, dirs, files in os.walk(folder, topdown=True, followlinks=False,
                                     onerror=walk_error):
        c._check_cancel(cancel)
        dirs.sort()
        files.sort()
        here = Path(base)
        follow_dirs = []
        for name in dirs + files:
            c._check_cancel(cancel)
            child = here / name
            rel = child.relative_to(folder)
            parts = rel.parts
            rel_name = "/".join(parts)
            examined += 1
            if examined == 1 or examined % 100 == 0:
                c._progress(progress, "確認", examined, 0)
            # Explicit opt-in: generated development environments can be
            # rebuilt, and can change while the app is running.
            if exclude_generated and name in dirs and name in GENERATED_DIRS:
                skipped.append(rel_name + "/ (開発環境)")
                continue
            try:
                info = child.lstat()
            except OSError as exc:
                raise c.VaultError(f"読み取れない項目があります: {rel_name}") from exc
            # Windows has junctions in addition to POSIX symlinks.
            is_junction = getattr(child, "is_junction", lambda: False)()
            if stat.S_ISLNK(info.st_mode) or is_junction:
                skipped.append(rel_name)
                continue
            if stat.S_ISDIR(info.st_mode):
                kind = 1
                length = 0
                if name in dirs:
                    follow_dirs.append(name)
            elif stat.S_ISREG(info.st_mode):
                kind = 2
                length = info.st_size
            else:
                # Sockets, devices, FIFOs etc cannot be recreated as ordinary
                # documents, and may block if opened. Never follow or read them.
                skipped.append(rel_name)
                continue
            for part in parts:
                c._safe_basename(part)
            rel_encoded = rel_name.encode("utf-8")
            if len(rel_encoded) > MAX_PATH_BYTES:
                raise c.VaultError("フォルダ内のパスが長すぎます。")
            # Avoid silent case collisions when restoring on Windows/macOS.
            normalized = rel_name.casefold()
            if normalized in seen_names:
                raise c.VaultError("大文字と小文字のみが異なる名前を同じフォルダに保存できません。")
            seen_names.add(normalized)
            entries.append((kind, child, rel_encoded, length, info.st_dev, info.st_ino, info.st_mtime_ns))
            total_data += RECORD.size + len(rel_encoded) + length
            if len(entries) > MAX_RECORDS:
                raise c.VaultError("フォルダ内の項目が多すぎます。")
        dirs[:] = follow_dirs  # Never descend into links/junctions.
    c._progress(progress, "確認", examined, 0)
    return entries, total_data, skipped


def encrypt_folder(input_folder, cipher_dir, key_dir, mode="os", progress=None,
                   cancel=None, hardware_path="/dev/hwrng", skipped=None,
                   exclude_generated=False):
    src = Path(input_folder).expanduser().resolve()
    if not src.is_dir():
        raise c.VaultError("暗号化するフォルダが見つかりません。")
    out_c = c._require_dir(cipher_dir, "暗号ファイルの保存先")
    out_k = c._require_dir(key_dir, "鍵ファイルの保存先")
    if out_c == out_k:
        raise c.VaultError("暗号ファイルと鍵ファイルは別の場所に保存してください。")
    if mode not in ("os", "hardware-mix"):
        raise c.VaultError("不明な乱数モードです。")
    name = c._safe_basename(src.name)
    entries, length, ignored = _scan(src, cancel, progress, exclude_generated)
    encoded = name.encode("utf-8")
    prefix = struct.pack(">H", len(encoded)) + encoded
    size = len(prefix) + len(DIR_SIGNATURE) + COUNT.size + length
    if size > c.MAX_PAYLOAD:
        raise c.VaultError("対応できる最大サイズを超えています。")
    c._check_free_space(out_c, out_k, size)
    rng_mode = c.MODE_OS if mode == "os" else c.MODE_HW_MIX
    identifier = secrets.token_bytes(16)
    hc = c.HEADER.pack(DIR_C, identifier, size, rng_mode)
    hk = c.HEADER.pack(DIR_K, identifier, size, rng_mode)
    auth_key = secrets.token_bytes(c.AUTH_SIZE)
    mac_c = hmac.new(auth_key, b"OTV-CIPHER-v1\0" + hc, hashlib.sha256)
    mac_k = hmac.new(auth_key, b"OTV-KEY-v1\0" + hk + auth_key, hashlib.sha256)
    out_cipher = c._available_name(out_c, c._cipher_visible_name(name) + ".otv")
    out_key = out_k / (secrets.token_hex(20) + ".otk")
    temp_c = temp_k = None
    try:
        with c.RandomSource(mode, hardware_path) as rng:
            cf, temp_c = c._temporary_file(out_c)
            try:
                kf, temp_k = c._temporary_file(out_k)
            except Exception:
                cf.close()
                raise
            with cf, kf:
                cf.write(hc)
                kf.write(hk + auth_key)
                key_commit = c._ProgressiveKeyCommit(kf, progress)
                done = 0
                def write_plain(block):
                    nonlocal done
                    limit = c.HW_CHUNK if mode == "hardware-mix" else c.CHUNK
                    for offset in range(0, len(block), limit):
                        c._check_cancel(cancel)
                        plain = block[offset:offset + limit]
                        pad = rng.get(len(plain), cancel)
                        encrypted = c._xor(plain, pad)
                        cf.write(encrypted)
                        kf.write(pad)
                        mac_c.update(encrypted)
                        mac_k.update(pad)
                        done += len(plain)
                        key_commit.wrote(len(pad), done, size)
                        c._progress(progress, "暗号化", done, size)
                write_plain(prefix)
                write_plain(DIR_SIGNATURE + COUNT.pack(len(entries)))
                for kind, path, rel, fsize, device, inode, modified in entries:
                    c._check_cancel(cancel)
                    current = path.lstat()
                    if kind == 1:
                        # A directory's mtime can change just because a child
                        # was added/removed. That is NOT a modification to an
                        # archived regular file. Still require the same dir
                        # (not a symlink, replaced directory, or a file).
                        unchanged = (stat.S_ISDIR(current.st_mode) and
                                     (current.st_dev, current.st_ino) == (device, inode))
                    else:
                        unchanged = (stat.S_ISREG(current.st_mode) and
                                     (current.st_dev, current.st_ino, current.st_mtime_ns,
                                      current.st_size) == (device, inode, modified, fsize))
                    if not unchanged:
                        raise c.VaultError(
                            f"暗号化中に次の項目が変更されました: {path.relative_to(src)}\n"
                            "対象ファイルを使っているアプリを閉じてから再試行してください。"
                        )
                    write_plain(RECORD.pack(kind, len(rel), fsize) + rel)
                    if kind == 2:
                        with path.open("rb") as fp:
                            opened = os.fstat(fp.fileno())
                            if (opened.st_dev, opened.st_ino, opened.st_mtime_ns, opened.st_size) != (device, inode, modified, fsize):
                                raise c.VaultError(
                                    f"暗号化中にファイルが変更されました: {path.relative_to(src)}\n"
                                    "ファイルを使用しているアプリを閉じてから再試行してください。"
                                )
                            left = fsize
                            while left:
                                c._check_cancel(cancel)
                                part = fp.read(min(c.HW_CHUNK if mode == "hardware-mix" else c.CHUNK, left))
                                if not part:
                                    raise c.VaultError(f"読み取り中にファイルが変更されました: {path.relative_to(src)}")
                                write_plain(part)
                                left -= len(part)
                            after = os.fstat(fp.fileno())
                            if after.st_mtime_ns != modified or after.st_size != fsize:
                                raise c.VaultError(
                                    f"暗号化中にファイルが変更されました: {path.relative_to(src)}\n"
                                    "ファイルを使用しているアプリを閉じてから再試行してください。"
                                )
                if done != size:
                    raise c.VaultError("フォルダ内のデータ長が一致しません。")
                cf.write(mac_c.digest())
                kf.write(mac_k.digest())
                c._progress(progress, "PCの暗号ファイル保存を確定中", size, size)
                cf.flush()
                os.fsync(cf.fileno())
                c._progress(progress, "USBの鍵を保存中", size, size)
                kf.flush()
                os.fsync(kf.fileno())
                c._progress(progress, "保存したファイルを確定中", size, size)
        c._check_cancel(cancel)
        if out_cipher.exists() or out_key.exists():
            raise c.VaultError("保存先に同名のファイルが存在します。")
        c._progress(progress, "USBとPCの保存を完了中", size, size)
        c._atomic_publish(temp_k, out_key)
        temp_k = None
        try:
            c._atomic_publish(temp_c, out_cipher)
            temp_c = None
        except Exception:
            out_key.unlink(missing_ok=True)
            raise
        if skipped is not None:
            skipped.extend(ignored)
        return out_cipher, out_key
    finally:
        if temp_c is not None:
            temp_c.unlink(missing_ok=True)
        if temp_k is not None:
            temp_k.unlink(missing_ok=True)


def decrypt_folder(cipher_path, key_path, output_dir, progress=None, cancel=None):
    encrypted = Path(cipher_path).expanduser().resolve()
    keyfile = Path(key_path).expanduser().resolve()
    out = c._require_dir(output_dir, "復号先")
    if not encrypted.is_file() or not keyfile.is_file():
        raise c.VaultError("暗号ファイルまたは鍵が見つかりません。")
    with encrypted.open("rb") as cf, keyfile.open("rb") as kf:
        hc, hk, size, auth = c._read_headers(cf, kf)
        if c.HEADER.unpack(hc)[0] != DIR_C:
            raise c.VaultError("これはフォルダ暗号ファイルではありません。")
        mac_c = hmac.new(auth, b"OTV-CIPHER-v1\0" + hc, hashlib.sha256)
        mac_k = hmac.new(auth, b"OTV-KEY-v1\0" + hk + auth, hashlib.sha256)
        done = 0
        while done < size:
            c._check_cancel(cancel)
            take = min(c.CHUNK, size - done)
            ciphertext, pad = cf.read(take), kf.read(take)
            if len(ciphertext) != take or len(pad) != take:
                raise c.VaultError("ファイルが途中で切れています。")
            mac_c.update(ciphertext)
            mac_k.update(pad)
            done += take
            c._progress(progress, "完全性の確認", done, size)
        if not hmac.compare_digest(cf.read(c.TAG_SIZE), mac_c.digest()):
            raise c.VaultError("暗号ファイルが破損または改ざんされています。")
        if not hmac.compare_digest(kf.read(c.TAG_SIZE), mac_k.digest()):
            raise c.VaultError("鍵ファイルが破損または改ざんされています。")
        c._check_cancel(cancel)
        cf.seek(c.HEADER.size)
        kf.seek(c.HEADER.size + c.AUTH_SIZE)
        remaining = size
        restored_bytes = 0

        def read_exact(n):
            nonlocal remaining, restored_bytes
            if n > remaining or n < 0:
                raise c.VaultError("フォルダの暗号化データが不正です。")
            c._check_cancel(cancel)
            a, b = cf.read(n), kf.read(n)
            if len(a) != n or len(b) != n:
                raise c.VaultError("復号中にデータを読み取れません。")
            remaining -= n
            restored_bytes += n
            c._progress(progress, "復号", restored_bytes, size)
            return c._xor(a, b)

        name_len = struct.unpack(">H", read_exact(2))[0]
        if not (1 <= name_len <= c.MAX_NAME_BYTES):
            raise c.VaultError("フォルダ名が不正です。")
        try:
            name = c._restored_basename(read_exact(name_len).decode("utf-8", "strict"))
        except UnicodeDecodeError as exc:
            raise c.VaultError("フォルダ名を読み取れません。") from exc
        if read_exact(len(DIR_SIGNATURE)) != DIR_SIGNATURE:
            raise c.VaultError("フォルダ暗号ファイルの構造が不正です。")
        num = COUNT.unpack(read_exact(COUNT.size))[0]
        if num > MAX_RECORDS:
            raise c.VaultError("フォルダ内の項目が多すぎます。")
        target = out / name
        if target.exists() or target.is_symlink():
            raise c.VaultError("復元先に同名ファイルがあります。")
        temporary = Path(tempfile.mkdtemp(prefix=".otv-folder-", dir=str(out)))
        names = set()
        try:
            for _ in range(num):
                kind, p_len, f_size = RECORD.unpack(read_exact(RECORD.size))
                if kind not in (1, 2) or p_len == 0 or (kind == 1 and f_size != 0):
                    raise c.VaultError("フォルダ内の項目が不正です。")
                try:
                    rawpath = read_exact(p_len).decode("utf-8", "strict")
                except UnicodeDecodeError as exc:
                    raise c.VaultError("フォルダ内のファイル名が不正です。") from exc
                parts = rawpath.split("/")
                if not parts or any(not part for part in parts):
                    raise c.VaultError("フォルダ内のパスが不正です。")
                parts = [c._restored_basename(part) for part in parts]
                canonical = rawpath.casefold()
                if canonical in names:
                    raise c.VaultError("フォルダ内のパスが重複しています。")
                names.add(canonical)
                dest = temporary.joinpath(*parts)
                if not dest.parent.is_dir():
                    raise c.VaultError("フォルダ構造が不正です。")
                if kind == 1:
                    dest.mkdir()
                else:
                    if f_size > remaining:
                        raise c.VaultError("暗号ファイルのデータ長が不正です。")
                    with dest.open("xb") as outf:
                        left = f_size
                        while left:
                            take = min(c.CHUNK, left)
                            outf.write(read_exact(take))
                            left -= take
                        outf.flush()
                        os.fsync(outf.fileno())
            if remaining != 0:
                raise c.VaultError("フォルダ暗号ファイルに余分なデータがあります。")
            c._check_cancel(cancel)
            if target.exists() or target.is_symlink():
                raise c.VaultError("復元先に同名ファイルがあります。")
            temporary.rename(target)
            return target
        finally:
            if temporary.exists():
                shutil.rmtree(temporary)
