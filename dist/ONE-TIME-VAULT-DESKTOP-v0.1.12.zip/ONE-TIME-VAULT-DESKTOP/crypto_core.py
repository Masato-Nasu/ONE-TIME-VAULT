"""ONE-TIME VAULT file format v1.

Educational, offline XOR-with-fresh-key vault. The OS CSPRNG provides
computational security, not a proof of information-theoretic one-time-pad security.
"""
from __future__ import annotations

import errno
import hashlib
import hmac
import os
import shutil
from pathlib import Path
import secrets
import struct
import sys
import tempfile
import unicodedata
from typing import Callable

MAGIC_C = b"OTVC1\0"
MAGIC_K = b"OTVK1\0"
MAGIC_C_DIR = b"OTVD1\0"
MAGIC_K_DIR = b"OTDK1\0"
HEADER = struct.Struct(">6s16sQB")  # magic / random file ID / payload bytes / RNG mode
AUTH_SIZE = 32
TAG_SIZE = 32
CHUNK = 1024 * 1024
# Commit the USB key progressively: cap the final device-cache writeback.
KEY_SYNC_INTERVAL = 16 * 1024 * 1024
HW_CHUNK = 64 * 1024
MAX_NAME_BYTES = 4096
MAX_PAYLOAD = (1 << 64) - 1
MODE_OS, MODE_HW_MIX = 0, 1
Progress = Callable[[str, int, int], None]


class VaultError(Exception):
    """Invalid, unsafe or damaged file / operation."""


class Cancelled(VaultError):
    pass


def _check_cancel(cancel):
    if cancel is not None and cancel.is_set():
        raise Cancelled("操作を中止しました。")


def _xor(a: bytes, b: bytes) -> bytes:
    """Bitwise XOR in native big-integer operations, with no external dependency.

    This is exactly the same operation and on-disk format as previous versions,
    but avoids interpreting each data byte in Python (important for large files).
    """
    if len(a) != len(b):
        raise VaultError("暗号データと鍵の長さが一致しません。")
    return (int.from_bytes(a, "little") ^ int.from_bytes(b, "little")).to_bytes(len(a), "little")


class RandomSource:
    """Always use OS CSPRNG; optionally XOR an additional Linux hwrng stream."""

    def __init__(self, mode: str = "os", hardware_path: str = "/dev/hwrng"):
        if mode not in ("os", "hardware-mix"):
            raise VaultError("乱数モードが不正です。")
        if mode == "hardware-mix" and not sys.platform.startswith("linux"):
            raise VaultError("ハードウェア混合モードはLinuxのみ対応です。")
        self.mode = mode
        self.hardware_path = hardware_path
        self._device = None

    def __enter__(self):
        if self.mode == "hardware-mix":
            try:
                self._device = open(self.hardware_path, "rb", buffering=0)
            except OSError as exc:
                raise VaultError("/dev/hwrng を読み取れません。OS乱数モードをお使いください。") from exc
        return self

    def __exit__(self, *_):
        if self._device:
            self._device.close()
            self._device = None

    def get(self, size: int, cancel=None) -> bytes:
        _check_cancel(cancel)
        data = os.urandom(size)
        if self._device is None:
            return data
        chunks = []
        remaining = size
        while remaining:
            _check_cancel(cancel)
            try:
                part = self._device.read(min(remaining, 8192))
            except OSError as exc:
                raise VaultError("ハードウェア乱数の取得に失敗しました。暗号化を中止します。") from exc
            if not part:
                raise VaultError("ハードウェア乱数が途中で途切れました。")
            chunks.append(part)
            remaining -= len(part)
        return _xor(data, b"".join(chunks))


def _progress(progress: Progress | None, phase, done, total):
    if progress:
        progress(phase, done, total)


class _ProgressiveKeyCommit:
    """Spread slow USB fsync across the stream instead of deferring 500MB.

    Never skips the final full flush+fsync. A failure leaves temp files unpublished.
    On a slow/failing USB the total work still takes time; this moves waits
    earlier, and may cost a little throughput. Do not remove fsync for speed.
    """

    def __init__(self, key_file, progress, interval=None):
        self.key_file = key_file
        self.progress = progress
        self.interval = KEY_SYNC_INTERVAL if interval is None else interval
        self.pending = 0

    def wrote(self, amount, done, total):
        self.pending += amount
        if self.pending >= self.interval:
            _progress(self.progress, "USBの鍵を段階保存中", done, total)
            self.key_file.flush()
            os.fsync(self.key_file.fileno())
            self.pending = 0



def _safe_basename(value: str) -> str:
    """Validate a single name without silently rewriting its original spelling.

    Linux permits tabs/newlines in file names. Those are real names and must be
    supported when encrypting a directory; rejecting them used to make an entire
    folder impossible to encrypt. Untrusted metadata is never allowed to contain
    a path separator, NUL, path traversal, or other unsafe characters.
    """
    if not value or value in (".", "..") or len(value.encode("utf-8")) > MAX_NAME_BYTES:
        raise VaultError("復元先のファイル名が不正です。")
    if any(ch in value for ch in "/\\\0:<>|?*\""):
        raise VaultError("ファイル名に使用できない文字があります。")
    # No control character occurs in a typical filename, but POSIX does permit
    # them except for NUL. Such names are handled safely by pathlib and open().
    stem = value.split(".", 1)[0].upper()
    if stem in {"CON", "PRN", "AUX", "NUL"} or any(stem == x + str(n) for x in ("COM", "LPT") for n in range(1, 10)):
        raise VaultError("復元先で使用できないファイル名です。")
    if value.endswith((".", " ")):
        raise VaultError("復元先で使用できないファイル名です。")
    return value


def _escape_controls(value: str) -> str:
    """Give the *visible* ciphertext a printable filename (metadata stays exact)."""
    return "".join(f"~U{ord(ch):04X}~" if unicodedata.category(ch) == "Cc" else ch for ch in value)


def _cipher_visible_name(original: str) -> str:
    """Make safe, short visible cipher names while keeping normal names intact."""
    name = _escape_controls(original)
    # POSIX commonly limits one filename component to 255 bytes, including
    # the appended .otv; leave a little margin for the collision suffix.
    if len((name + ".otv").encode("utf-8")) <= 230:
        return name
    suffix = "~" + hashlib.sha256(original.encode("utf-8")).hexdigest()[:12]
    prefix = ""
    for ch in name:
        if len((prefix + ch + suffix + ".otv").encode("utf-8")) > 230:
            break
        prefix += ch
    return prefix + suffix


def _restored_basename(original: str) -> str:
    """On platforms disallowing control chars, use printable equivalents.

    The encrypted metadata retains the original spelling, so Linux can restore
    the exact name. On Windows/macOS, an escaped name avoids an unsafe/failed
    restore. Normal user names remain unchanged on all platforms.
    """
    valid = _safe_basename(original)
    if sys.platform in ("win32", "darwin"):
        return _cipher_visible_name(valid)
    return valid


def _temporary_file(directory: Path):
    fd, name = tempfile.mkstemp(prefix=".otv-", suffix=".tmp", dir=str(directory))
    return os.fdopen(fd, "w+b"), Path(name)


def _atomic_publish(temporary: Path, final: Path):
    # Prefer atomic no-clobber hard-link publishing. Some external USB drives
    # (FAT / exFAT) cannot make hard links, so fall back to a same-folder rename.
    try:
        os.link(str(temporary), str(final))
    except OSError as exc:
        if exc.errno not in (errno.EPERM, errno.EACCES, errno.EOPNOTSUPP, errno.ENOTSUP, errno.ENOSYS, errno.EINVAL):
            raise
        if final.exists() or final.is_symlink():
            raise FileExistsError(f"保存先ファイルが既にあります: {final}") from exc
        os.rename(str(temporary), str(final))  # best effort for FAT / exFAT
        return
    temporary.unlink()


def _check_free_space(cipher_dir: Path, key_dir: Path, payload_size: int):
    """Catch common USB-full failures before writing a huge one-time key.

    Free space is advisory (other processes may write concurrently). A final
    fsync is still required to verify storage errors.
    """
    needed_cipher = HEADER.size + payload_size + TAG_SIZE
    needed_key = HEADER.size + AUTH_SIZE + payload_size + TAG_SIZE
    cipher_free = shutil.disk_usage(cipher_dir).free
    key_free = shutil.disk_usage(key_dir).free
    if key_free < needed_key:
        raise VaultError(
            f"USBの空き容量が足りません。鍵には約 {needed_key / (1024**2):,.1f} MB 必要ですが、"
            f"空きは約 {key_free / (1024**2):,.1f} MB です。"
        )
    if cipher_free < needed_cipher:
        raise VaultError("PCの暗号化フォルダの空き容量が足りません。")


def _require_dir(path: str | Path, label: str) -> Path:
    p = Path(path).expanduser().resolve()
    if not p.is_dir():
        raise VaultError(f"{label}フォルダーが存在しません: {p}")
    return p


def _available_name(folder: Path, filename: str) -> Path:
    """Pick a friendly non-overwriting filename, even across repeated operations."""
    proposed = folder / filename
    if not proposed.exists() and not proposed.is_symlink():
        return proposed
    # Keep the .otv extension for cipher files; do not change the source name.
    base, ext = (filename[:-4], ".otv") if filename.endswith(".otv") else (filename, "")
    for i in range(2, 10001):
        proposed = folder / f"{base} ({i}){ext}"
        if not proposed.exists() and not proposed.is_symlink():
            return proposed
    raise VaultError("同名のファイルが多すぎます。保存先を整理してください。")


def cipher_identity(cipher_path: str | Path) -> tuple[bytes, int, int]:
    """Extract the opaque file ID for matching, independent of its filename."""
    p = Path(cipher_path).expanduser()
    try:
        with p.open("rb") as fp:
            buf = fp.read(HEADER.size)
        if len(buf) != HEADER.size:
            raise VaultError("暗号ファイルの形式が不正です。")
        magic, ident, size, mode = HEADER.unpack(buf)
        if magic not in (MAGIC_C, MAGIC_C_DIR) or mode not in (MODE_OS, MODE_HW_MIX):
            raise VaultError("ONE-TIME VAULT の暗号ファイルではありません。")
        if p.stat().st_size != HEADER.size + size + TAG_SIZE:
            raise VaultError("暗号ファイルのサイズが不正です。")
        return ident, size, mode
    except (PermissionError, IsADirectoryError) as exc:
        raise VaultError("暗号ファイルを読み取れません。") from exc


def find_matching_keys(cipher_path: str | Path, roots: list[str | Path],
                       cancel=None) -> list[Path]:
    """Search key headers by embedded ID/size/mode, regardless of filenames.

    Candidate files are not trusted until decrypt_file verifies BOTH HMACs.
    Symlinked directories and files are skipped to avoid leaving the USB.
    """
    ident, size, mode = cipher_identity(cipher_path)
    with Path(cipher_path).expanduser().open("rb") as cf:
        cipher_identity_magic = cf.read(6)
    candidates = []
    expected_size = HEADER.size + AUTH_SIZE + size + TAG_SIZE
    seen = set()
    for root in roots:
        folder = Path(root).expanduser().resolve()
        if not folder.is_dir():
            continue
        for base, dirs, files in os.walk(folder, followlinks=False):
            _check_cancel(cancel)
            dirs[:] = [d for d in dirs if not (Path(base) / d).is_symlink()]
            for name in files:
                _check_cancel(cancel)
                path = Path(base) / name
                try:
                    if path.is_symlink() or path.stat().st_size != expected_size:
                        continue
                    with path.open("rb") as fh:
                        head = fh.read(HEADER.size)
                    if len(head) != HEADER.size:
                        continue
                    magic, file_id, nbytes, rng_mode = HEADER.unpack(head)
                    expected_magic = MAGIC_K_DIR if cipher_identity_magic == MAGIC_C_DIR else MAGIC_K
                    if (magic, file_id, nbytes, rng_mode) == (expected_magic, ident, size, mode):
                        canon = str(path.resolve())
                        if canon not in seen:
                            seen.add(canon)
                            candidates.append(path)
                except (OSError, ValueError, struct.error):
                    continue
    return candidates


def decrypt_auto(cipher_path: str | Path, key_roots: list[str | Path],
                 output_dir: str | Path, progress: Progress | None = None,
                 cancel=None) -> tuple[Path, Path]:
    """Find the correct key by internal ID, authenticate it, and restore."""
    matches = find_matching_keys(cipher_path, key_roots, cancel)
    if not matches:
        raise VaultError("USB内に対応する鍵がありません。鍵が保存されたUSBを挿してください。")
    last_error = None
    for candidate in matches:
        _check_cancel(cancel)
        try:
            return decrypt_file(cipher_path, candidate, output_dir, progress, cancel), candidate
        except Cancelled:
            raise
        except (VaultError, OSError) as exc:
            if isinstance(exc, VaultError) and "復元先に同名ファイル" in str(exc):
                raise
            last_error = exc
    raise VaultError("対応する鍵が見つかりましたが、復元できませんでした。鍵や暗号ファイルが破損している可能性があります。") from last_error


def encrypt_file(input_path: str | Path, cipher_dir: str | Path, key_dir: str | Path,
                 mode: str = "os", progress: Progress | None = None, cancel=None,
                 hardware_path: str = "/dev/hwrng") -> tuple[Path, Path]:
    source = Path(input_path).expanduser().resolve()
    if not source.is_file():
        raise VaultError("元のファイルが見つかりません。")
    out_c = _require_dir(cipher_dir, "暗号ファイルの保存先")
    out_k = _require_dir(key_dir, "鍵ファイルの保存先")
    if out_c == out_k:
        raise VaultError("暗号ファイルと鍵ファイルは、異なるフォルダーに保存してください。")
    # Output directories are distinct but can be on the same disk. Document the risk.
    name = _safe_basename(source.name)
    encoded = name.encode("utf-8")
    prefix = struct.pack(">H", len(encoded)) + encoded
    size = source.stat().st_size + len(prefix)
    if size > MAX_PAYLOAD:
        raise VaultError("対応できる最大サイズを超えています。")
    rng_mode = MODE_OS if mode == "os" else MODE_HW_MIX
    if mode not in ("os", "hardware-mix"):
        raise VaultError("不明な乱数モードです。")
    _check_free_space(out_c, out_k, size)
    file_id = secrets.token_bytes(16)
    # Preserve the original visible name by default (a deliberate UI choice).
    # Never rely on either filename for the relationship between key and cipher.
    output_c = _available_name(out_c, _cipher_visible_name(name) + ".otv")
    output_k = out_k / (secrets.token_hex(20) + ".otk")
    header_c = HEADER.pack(MAGIC_C, file_id, size, rng_mode)
    header_k = HEADER.pack(MAGIC_K, file_id, size, rng_mode)
    mac_key = secrets.token_bytes(AUTH_SIZE)
    mac_c = hmac.new(mac_key, b"OTV-CIPHER-v1\0" + header_c, hashlib.sha256)
    mac_k = hmac.new(mac_key, b"OTV-KEY-v1\0" + header_k + mac_key, hashlib.sha256)
    tc = tk = None
    try:
        with RandomSource(mode, hardware_path) as rng:
            cf, tc = _temporary_file(out_c)
            try:
                kf, tk = _temporary_file(out_k)
            except Exception:
                cf.close()
                raise
            with cf, kf, source.open("rb") as inp:
                cf.write(header_c)
                kf.write(header_k + mac_key)
                key_commit = _ProgressiveKeyCommit(kf, progress)
                done = 0
                # Metadata uses the same pad as the file body, not plaintext headers.
                _check_cancel(cancel)
                first = rng.get(len(prefix), cancel)
                kf.write(first)
                mac_k.update(first)
                ciphertext = _xor(prefix, first)
                cf.write(ciphertext)
                mac_c.update(ciphertext)
                done += len(prefix)
                key_commit.wrote(len(first), done, size)
                _progress(progress, "暗号化", done, size)
                while True:
                    _check_cancel(cancel)
                    plain = inp.read(HW_CHUNK if mode == "hardware-mix" else CHUNK)
                    if not plain:
                        break
                    pad = rng.get(len(plain), cancel)
                    kf.write(pad)
                    mac_k.update(pad)
                    encrypted = _xor(plain, pad)
                    cf.write(encrypted)
                    mac_c.update(encrypted)
                    done += len(plain)
                    key_commit.wrote(len(pad), done, size)
                    _progress(progress, "暗号化", done, size)
                # Detect source mutation that would lead to an incomplete ciphertext.
                if done != size or inp.read(1):
                    raise VaultError("読み取り中に元ファイルが変更されました。操作を中止しました。")
                cf.write(mac_c.digest())
                kf.write(mac_k.digest())
                _progress(progress, "PCの暗号ファイル保存を確定中", size, size)
                cf.flush()
                os.fsync(cf.fileno())
                _progress(progress, "USBの鍵を保存中", size, size)
                kf.flush()
                os.fsync(kf.fileno())
                _progress(progress, "保存したファイルを確定中", size, size)
        _check_cancel(cancel)
        if output_c.exists() or output_k.exists():
            raise VaultError("同じIDのファイルが既にあります。")
        # Publish the key first so the ciphertext is not visible without its key.
        _progress(progress, "USBとPCの保存を完了中", size, size)
        # If the second publish fails, unlink the first.
        _atomic_publish(tk, output_k)
        tk = None
        try:
            _atomic_publish(tc, output_c)
            tc = None
        except Exception:
            output_k.unlink(missing_ok=True)
            raise
        return output_c, output_k
    finally:
        if tc is not None:
            tc.unlink(missing_ok=True)
        if tk is not None:
            tk.unlink(missing_ok=True)


def _read_headers(cipher, key):
    hc = cipher.read(HEADER.size)
    hk = key.read(HEADER.size)
    if len(hc) != HEADER.size or len(hk) != HEADER.size:
        raise VaultError("ファイルのヘッダーが不正です。")
    magic_c, id_c, size_c, mode_c = HEADER.unpack(hc)
    magic_k, id_k, size_k, mode_k = HEADER.unpack(hk)
    if (magic_c, magic_k) not in ((MAGIC_C, MAGIC_K), (MAGIC_C_DIR, MAGIC_K_DIR)):
        raise VaultError("ONE-TIME VAULT のファイルではないか、形式が異なります。")
    if id_c != id_k or size_c != size_k or mode_c != mode_k:
        raise VaultError("暗号ファイルと鍵ファイルが一致しません。")
    if mode_c not in (MODE_OS, MODE_HW_MIX):
        raise VaultError("乱数方式が不正です。")
    # Exactly the amount needed, no hidden data following the footer.
    if Path(cipher.name).stat().st_size != HEADER.size + size_c + TAG_SIZE:
        raise VaultError("暗号ファイルの長さが不正です。")
    if Path(key.name).stat().st_size != HEADER.size + AUTH_SIZE + size_k + TAG_SIZE:
        raise VaultError("鍵ファイルの長さが不正です。")
    secret = key.read(AUTH_SIZE)
    if len(secret) != AUTH_SIZE:
        raise VaultError("鍵ファイルが壊れています。")
    return hc, hk, size_c, secret


def decrypt_file(cipher_path: str | Path, key_path: str | Path, output_dir: str | Path,
                 progress: Progress | None = None, cancel=None) -> Path:
    cipher_path, key_path = Path(cipher_path).expanduser().resolve(), Path(key_path).expanduser().resolve()
    with cipher_path.open("rb") as probe:
        if probe.read(6) == MAGIC_C_DIR:
            from folder_core import decrypt_folder
            return decrypt_folder(cipher_path, key_path, output_dir, progress, cancel)
    out = _require_dir(output_dir, "復元先")
    if not cipher_path.is_file() or not key_path.is_file():
        raise VaultError("暗号ファイルまたは鍵ファイルが見つかりません。")
    with cipher_path.open("rb") as cf, key_path.open("rb") as kf:
        hc, hk, size, auth = _read_headers(cf, kf)
        cm = hmac.new(auth, b"OTV-CIPHER-v1\0" + hc, hashlib.sha256)
        km = hmac.new(auth, b"OTV-KEY-v1\0" + hk + auth, hashlib.sha256)
        done = 0
        while done < size:
            _check_cancel(cancel)
            take = min(CHUNK, size - done)
            cp = cf.read(take)
            kp = kf.read(take)
            if len(cp) != take or len(kp) != take:
                raise VaultError("ファイルが途中で切れています。")
            cm.update(cp)
            km.update(kp)
            done += take
            _progress(progress, "完全性の確認", done, size)
        if not hmac.compare_digest(cf.read(TAG_SIZE), cm.digest()):
            raise VaultError("暗号ファイルが破損または改ざんされています。")
        if not hmac.compare_digest(kf.read(TAG_SIZE), km.digest()):
            raise VaultError("鍵ファイルが破損または改ざんされています。")
        _check_cancel(cancel)
        cf.seek(HEADER.size)
        kf.seek(HEADER.size + AUTH_SIZE)
        # Read metadata from the encrypted stream before constructing any path.
        if size < 3:
            raise VaultError("暗号化データが短すぎます。")
        length_bytes = _xor(cf.read(2), kf.read(2))
        name_len = struct.unpack(">H", length_bytes)[0]
        if name_len < 1 or name_len > MAX_NAME_BYTES or (2 + name_len) > size:
            raise VaultError("暗号化されたファイル名の長さが不正です。")
        try:
            decoded_name = _xor(cf.read(name_len), kf.read(name_len)).decode("utf-8", errors="strict")
        except UnicodeDecodeError as exc:
            raise VaultError("暗号化されたファイル名を復元できません。") from exc
        filename = _restored_basename(decoded_name)
        target = out / filename
        if target.exists() or target.is_symlink():
            raise VaultError("復元先に同名ファイルがあります。別のフォルダーを選択してください。")
        temp = None
        try:
            of, temp = _temporary_file(out)
            with of:
                remaining = size - 2 - name_len
                restored = 0
                while remaining:
                    _check_cancel(cancel)
                    take = min(CHUNK, remaining)
                    a, b = cf.read(take), kf.read(take)
                    if len(a) != take or len(b) != take:
                        raise VaultError("復元中にファイルが読み取れなくなりました。")
                    of.write(_xor(a, b))
                    restored += take
                    remaining -= take
                    _progress(progress, "復元", restored, size - 2 - name_len)
                of.flush()
                os.fsync(of.fileno())
            _check_cancel(cancel)
            _atomic_publish(temp, target)
            temp = None
        finally:
            if temp is not None:
                temp.unlink(missing_ok=True)
        return target
