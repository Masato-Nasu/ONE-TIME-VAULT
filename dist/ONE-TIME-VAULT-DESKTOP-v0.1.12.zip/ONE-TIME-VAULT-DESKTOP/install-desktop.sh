#!/usr/bin/env bash
# Install just for the current user; never requires sudo or modifies user files.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="$HOME/.local/share/one-time-vault"
APPLICATIONS="$HOME/.local/share/applications"
AUTOSTART="$HOME/.config/autostart"
BIN="$HOME/.local/bin"
DESKTOP="${XDG_DESKTOP_DIR:-$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")}"
if ! python3 -c 'import tkinter' >/dev/null 2>&1; then
  echo 'tkinter が必要です: sudo apt install python3-tk'; exit 1
fi
if ! python3 -m venv --help >/dev/null 2>&1; then
  echo 'venv が必要です: sudo apt install python3-venv'; exit 1
fi
mkdir -p "$APP" "$APPLICATIONS" "$AUTOSTART" "$BIN"
# Install application modules and assets; leave .venv and any existing user files intact.
for file in main.py i18n.py crypto_core.py folder_core.py usb_drives.py tray_support.py instance_ipc.py VERSION.txt; do
  cp "$HERE/$file" "$APP/$file"
done
cp -R "$HERE/assets" "$APP/"
cp "$HERE/launch-linux.sh" "$APP/launch-linux.sh"
cp "$HERE/uninstall-desktop.sh" "$APP/uninstall-desktop.sh"
chmod +x "$APP/launch-linux.sh" "$APP/uninstall-desktop.sh"
if [ ! -x "$APP/.venv/bin/python" ]; then
  python3 -m venv --system-site-packages "$APP/.venv"
fi
printf '\n常駐アイコンの動作に必要なライブラリを準備しています…\n'
if ! "$APP/.venv/bin/python" -m pip install --disable-pip-version-check 'pystray==0.19.5' 'Pillow>=10,<12'; then
  echo 'ライブラリの導入に失敗しました。ネット接続を確認し、再実行してください。'
  echo 'アプリの暗号化・復号は、メニューから通常のウィンドウとして起動できます。'
  exit 1
fi
cat > "$APPLICATIONS/one-time-vault.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=ONE-TIME VAULT
Comment=Offline encryption with USB keys / USB鍵を分離
Exec=$APP/launch-linux.sh
Icon=$APP/assets/one-time-vault-256.png
Terminal=false
Categories=Utility;Security;
StartupNotify=true
EOF
cat > "$AUTOSTART/one-time-vault.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=ONE-TIME VAULT (Tray)
Comment=Start in the system tray at login
Exec=$APP/launch-linux.sh --background
Icon=$APP/assets/one-time-vault-256.png
Terminal=false
X-GNOME-Autostart-enabled=true
EOF
# Desktop shortcut is optional; menu entry and autostart are the primary interfaces.
if [ -d "$DESKTOP" ]; then
  cp "$APPLICATIONS/one-time-vault.desktop" "$DESKTOP/ONE-TIME VAULT.desktop"
  chmod +x "$DESKTOP/ONE-TIME VAULT.desktop"
fi
printf '\n✅ インストール完了: ONE-TIME VAULT\n'
printf 'メニューで「ONE-TIME VAULT」を検索すると起動できます。\n'
printf '次回ログインから自動起動します。\n'
printf '一度開いたあと右上の×で閉じると、通知領域に常駐します。\n'
"$APP/launch-linux.sh" >/dev/null 2>&1 &
disown 2>/dev/null || true
